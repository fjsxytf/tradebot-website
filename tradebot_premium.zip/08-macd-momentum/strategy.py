"""
MACD 动量策略 - Python 实盘版本
策略编号: 08
价格: $4.99 (进阶系列)
"""

import asyncio
import json
import logging
from dataclasses import dataclass
from typing import Optional, List
import pandas as pd
import numpy as np

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class StrategyConfig:
    macd_fast: int = 12
    macd_slow: int = 26
    macd_signal: int = 9
    momentum_bars: int = 3
    risk_per_trade: float = 0.02
    exchanges: List[str] = None
    
    def __post_init__(self):
        if self.exchanges is None:
            self.exchanges = ["hyperliquid"]


class MACDMomentum:
    """
    MACD 动量策略
    
    核心逻辑:
    1. 计算 MACD 线和信号线
    2. 关注柱状图（Histogram）的动量变化
    3. 柱状图连续扩大 = 趋势加速 = 开仓
    4. 柱状图连续缩小 = 趋势减速 = 平仓
    """
    
    def __init__(self, config: StrategyConfig):
        self.config = config
        self.position = 0
        self.data = pd.DataFrame()
        
    def calculate_macd(self, prices: pd.Series) -> tuple:
        """计算 MACD"""
        ema_fast = prices.ewm(span=self.config.macd_fast, adjust=False).mean()
        ema_slow = prices.ewm(span=self.config.macd_slow, adjust=False).mean()
        macd_line = ema_fast - ema_slow
        signal_line = macd_line.ewm(span=self.config.macd_signal, adjust=False).mean()
        histogram = macd_line - signal_line
        return macd_line, signal_line, histogram
    
    def check_momentum(self, series: pd.Series, bars: int, direction: str = "expanding") -> bool:
        """
        检查动量方向
        
        Args:
            series: 柱状图数据
            bars: 连续K线数
            direction: "expanding" 扩大 or "contracting" 缩小
        """
        if len(series) < bars + 1:
            return False
        
        recent = series.tail(bars).values
        if direction == "expanding":
            return all(recent[i] > recent[i-1] for i in range(1, len(recent)))
        else:
            return all(recent[i] < recent[i-1] for i in range(1, len(recent)))
    
    def generate_signal(self) -> Optional[str]:
        """生成交易信号"""
        if len(self.data) < self.config.macd_slow + 10:
            return None
        
        macd_line, signal_line, histogram = self.calculate_macd(self.data['close'])
        
        current_hist = histogram.iloc[-1]
        prev_hist = histogram.iloc[-2]
        
        # 检查动量
        expanding = self.check_momentum(histogram, self.config.momentum_bars, "expanding")
        contracting = self.check_momentum(histogram, 2, "contracting")
        
        macd_above_signal = macd_line.iloc[-1] > signal_line.iloc[-1]
        
        if self.position == 0:
            if current_hist > 0 and expanding and macd_above_signal:
                logger.info(f"🟢 MACD动量做多 | Hist: {current_hist:.4f}")
                return "long"
            elif current_hist < 0 and expanding and not macd_above_signal:
                logger.info(f"🔴 MACD动量做空 | Hist: {current_hist:.4f}")
                return "short"
        
        elif self.position == 1 and contracting:
            logger.info("📕 MACD动量减弱，平多仓")
            return "close_long"
        
        elif self.position == -1 and contracting:
            logger.info("📗 MACD动量减弱，平空仓")
            return "close_short"
        
        return None
    
    async def run(self):
        """主运行循环"""
        logger.info("=" * 50)
        logger.info("MACD 动量策略启动")
        logger.info(f"配置: MACD({self.config.macd_fast},{self.config.macd_slow},{self.config.macd_signal})")
        logger.info("=" * 50)
        
        while True:
            try:
                signal = self.generate_signal()
                if signal:
                    current_price = self.data['close'].iloc[-1] if len(self.data) > 0 else 0
                    if signal == "long":
                        self.position = 1
                        logger.info(f"🚀 开多仓 @ {current_price:.2f}")
                    elif signal == "short":
                        self.position = -1
                        logger.info(f"🚀 开空仓 @ {current_price:.2f}")
                    elif signal in ["close_long", "close_short"]:
                        self.position = 0
                        logger.info(f"🔒 平仓 @ {current_price:.2f}")
                
                await asyncio.sleep(60)
                
            except Exception as e:
                logger.error(f"策略运行错误: {e}")
                await asyncio.sleep(60)


def load_config(path: str) -> StrategyConfig:
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    macd = data.get("indicators", {}).get("macd", {})
    return StrategyConfig(
        macd_fast=macd.get("fast", 12),
        macd_slow=macd.get("slow", 26),
        macd_signal=macd.get("signal", 9),
        risk_per_trade=data.get("risk_management", {}).get("risk_per_trade", 0.02),
        exchanges=data.get("exchanges", ["hyperliquid"])
    )


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config.json")
    args = parser.parse_args()
    
    config = load_config(args.config)
    strategy = MACDMomentum(config)
    asyncio.run(strategy.run())
