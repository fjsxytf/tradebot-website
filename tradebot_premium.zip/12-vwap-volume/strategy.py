"""
套餐 12：VWAP 量價結合策略 (VWAP Volume Strategy)
交易所：Hyperliquid / Binance / OKX
"""

import json
import time
import logging
from datetime import datetime
from typing import Optional

try:
    import ccxt
    import pandas as pd
    import numpy as np
    HAS_DEPS = True
except ImportError:
    HAS_DEPS = False
    print("⚠️ 缺少依賴，請運行：pip install ccxt pandas numpy")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("vwap.log", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("VWAPStrategy")


class VWAPConfig:
    def __init__(self, config_path: str = None):
        if config_path:
            with open(config_path, "r", encoding="utf-8") as f:
                cfg = json.load(f)
        else:
            cfg = self._default()
        self.symbol      = cfg.get("symbol", "BTC/USDT:USDT")
        self.timeframe   = cfg.get("timeframe", "15m")
        p = cfg["parameters"]
        self.vwap_std    = p["vwap_std_dev"]
        self.vol_ma_period = p["volume_ma_period"]
        self.vol_mult    = p["volume_multiplier"]
        self.sl_pct      = p["stop_loss_pct"]
        self.tp_pct      = p["take_profit_pct"]
        self.obp_enabled = p.get("obp_enabled", False)

    @staticmethod
    def _default():
        return {
            "symbol": "BTC/USDT:USDT",
            "timeframe": "15m",
            "parameters": {
                "vwap_std_dev": 1.5,
                "volume_ma_period": 20,
                "volume_multiplier": 1.8,
                "obp_enabled": False,
                "session_only": True,
                "stop_loss_pct": 1.5,
                "take_profit_pct": 4.5
            }
        }


class VWAPIndicator:
    """VWAP 指標計算"""

    @staticmethod
    def calculate(df: pd.DataFrame, std_mult: float = 1.5) -> pd.DataFrame:
        """
        計算 VWAP 及標準偏差帶
        """
        typical = (df["high"] + df["low"] + df["close"]) / 3
        cum_typ = (typical * df["volume"]).cumsum()
        cum_vol = df["volume"].cumsum()
        df["vwap"] = cum_typ / cum_vol

        # 標準偏差帶
        df["vwap_std"] = df["close"].rolling(20).std()
        df["vwap_upper"] = df["vwap"] + df["vwap_std"] * std_mult
        df["vwap_lower"] = df["vwap"] - df["vwap_std"] * std_mult

        # 偏離度
        df["vwap_deviation"] = (df["close"] - df["vwap"]) / df["vwap"] * 100

        return df

    @staticmethod
    def generate_signal(df: pd.DataFrame, vol_ma_period: int, vol_mult: float) -> int:
        """
        生成信號：1=買入, -1=賣出, 0=無信號
        """
        if len(df) < 20:
            return 0

        vol_ma = df["volume"].iloc[-vol_ma_period:].mean()
        has_vol = df["volume"].iloc[-1] >= vol_ma * vol_mult

        prev_close = df["close"].iloc[-2]
        curr_close = df["close"].iloc[-1]
        prev_vwap  = df["vwap"].iloc[-2]
        curr_vwap  = df["vwap"].iloc[-1]

        # 上穿
        if prev_close <= prev_vwap and curr_close > curr_vwap and has_vol:
            logger.info(f"🔔 VWAP 上穿！價格={curr_close:.4f}, VWAP={curr_vwap:.4f}")
            return 1
        # 下穿
        elif prev_close >= prev_vwap and curr_close < curr_vwap and has_vol:
            logger.info(f"🔔 VWAP 下穿！價格={curr_close:.4f}, VWAP={curr_vwap:.4f}")
            return -1
        return 0


class VWAPStrategy:
    def __init__(self, exchange_name: str, config: VWAPConfig):
        if not HAS_DEPS:
            raise RuntimeError("缺少依賴包")

        self.config = config
        if exchange_name == "hyperliquid":
            self.exchange = ccxt.hyperliquid({"enableRateLimit": True})
        elif exchange_name == "binance":
            self.exchange = ccxt.binance({"enableRateLimit": True})
        elif exchange_name == "okx":
            self.exchange = ccxt.okx({"enableRateLimit": True})
        else:
            raise ValueError(f"不支持的交易所：{exchange_name}")

        self.position = 0
        logger.info(f"VWAP 策略初始化：{exchange_name}, {config.symbol}")

    def load_data(self, limit: int = 500) -> pd.DataFrame:
        logger.info(f"正在獲取 K 線數據 (limit={limit})...")
        ohlcv = self.exchange.fetch_ohlcv(self.config.symbol, self.config.timeframe, limit=limit)
        df = pd.DataFrame(ohlcv, columns=["timestamp", "open", "high", "low", "close", "volume"])
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")
        df.set_index("timestamp", inplace=True)
        return df

    def run_backtest(self, df: pd.DataFrame) -> dict:
        df = VWAPIndicator.calculate(df, self.config.vwap_std)
        capital = 10000.0
        position = 0.0
        entry = 0.0
        trades = []
        equity = []

        for i in range(50, len(df)):
            signal = VWAPIndicator.generate_signal(df.iloc[:i+1],
                            self.config.vol_ma_period, self.config.vol_mult)
            row = df.iloc[i]

            if signal == 1 and position == 0:
                entry = row["close"]
                position = capital / entry
                logger.info(f"[回測] 買入 VWAP @ {entry:.4f}")
            elif signal == -1 and position > 0:
                exit_price = row["close"]
                pnl = (exit_price - entry) * position
                capital += pnl
                trades.append({"entry": entry, "exit": exit_price, "pnl": pnl})
                logger.info(f"[回測] 賣出 @ {exit_price:.4f}, PnL={pnl:.2f}")
                position = 0.0

            cur_val = capital + position * row["close"] if position > 0 else capital
            equity.append(cur_val)

        wins = [t for t in trades if t["pnl"] > 0]
        return {
            "total_trades": len(trades),
            "win_trades": len(wins),
            "win_rate": len(wins) / len(trades) if trades else 0,
            "total_pnl": sum(t["pnl"] for t in trades),
            "final_equity": equity[-1] if equity else capital,
        }

    def live_run(self, poll_seconds: int = 60):
        logger.info("🟢 VWAP 實盤模式啟動")
        df = self.load_data(500)
        df = VWAPIndicator.calculate(df, self.config.vwap_std)
        last_signal = 0

        while True:
            try:
                ohlcv = self.exchange.fetch_ohlcv(self.config.symbol, self.config.timeframe, limit=2)
                if ohlcv[-1][0] != df.index[-1]:
                    new_row = pd.DataFrame([ohlcv[-1]],
                        columns=["timestamp","open","high","low","close","volume"])
                    new_row["timestamp"] = pd.to_datetime(new_row["timestamp"], unit="ms")
                    new_row.set_index("timestamp", inplace=True)
                    df = pd.concat([df, new_row])

                df = VWAPIndicator.calculate(df, self.config.vwap_std)
                signal = VWAPIndicator.generate_signal(df,
                                self.config.vol_ma_period, self.config.vol_mult)

                if signal == 1 and last_signal != 1:
                    self._place_order("buy")
                    last_signal = 1
                elif signal == -1 and last_signal != -1:
                    self._place_order("sell")
                    last_signal = -1

                logger.info(f"監控中... VWAP={df['vwap'].iloc[-1]:.4f}, 偏離={(df['vwap_deviation'].iloc[-1]):.2f}%")
            except Exception as e:
                logger.error(f"錯誤：{e}")
            time.sleep(poll_seconds)

    def _place_order(self, side: str):
        try:
            order = self.exchange.create_market_order(self.config.symbol, side, 0.01)
            logger.info(f"✅ 訂單成交：{json.dumps(order, ensure_ascii=False)}")
        except Exception as e:
            logger.error(f"❌ 下單失敗：{e}")


def main():
    config = VWAPConfig()
    strategy = VWAPStrategy("hyperliquid", config)

    print("=" * 50)
    print("📊 VWAP 策略回測")
    print("=" * 50)
    df = strategy.load_data(1000)
    result = strategy.run_backtest(df)
    print(f"總交易：{result['total_trades']} | 勝率：{result['win_rate']*100:.1f}% | 盈虧：{result['total_pnl']:.2f} USDT")

    # strategy.live_run()


if __name__ == "__main__":
    main()
