#!/usr/bin/env python3
"""
EMA10 Trend Following Strategy - Python Implementation
加密货币自动化交易脚本

作者: TradeBot
版本: 1.0
"""

import json
import time
import logging
from datetime import datetime
from typing import Optional, Dict, List

try:
    import requests
except ImportError:
    print("请先安装 requests: pip install requests")
    exit(1)

# ============== 配置区域 ==============
# 从 config.json 加载配置
with open("config.json", "r", encoding="utf-8") as f:
    config = json.load(f)

# 日志配置
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('trading_log.txt', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# ============== API 配置 ==============
# 使用免费公开 API（无需 API Key）
BINANCE_API_BASE = "https://api.binance.com/api/v3"

# ============== 工具函数 ==============

def get_klines(symbol: str, interval: str = "4h", limit: int = 100) -> List[Dict]:
    """获取 K 线数据"""
    url = f"{BINANCE_API_BASE}/klines"
    params = {"symbol": symbol, "interval": interval, "limit": limit}
    
    try:
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        # 转换为标准格式
        klines = []
        for k in data:
            klines.append({
                "open_time": k[0],
                "open": float(k[1]),
                "high": float(k[2]),
                "low": float(k[3]),
                "close": float(k[4]),
                "volume": float(k[5]),
                "close_time": k[6]
            })
        return klines
    except Exception as e:
        logger.error(f"获取 {symbol} K线数据失败: {e}")
        return []

def calculate_ema(prices: List[float], period: int) -> float:
    """计算 EMA"""
    if len(prices) < period:
        return 0.0
    
    multiplier = 2 / (period + 1)
    ema = sum(prices[:period]) / period
    
    for price in prices[period:]:
        ema = (price - ema) * multiplier + ema
    
    return ema

def get_ema_trend(symbol: str, period: int = 10) -> Dict:
    """分析 EMA 趋势"""
    klines = get_klines(symbol, interval="4h", limit=100)
    
    if len(klines) < period + 1:
        return {"signal": "N/A", "trend": "数据不足"}
    
    # 获取收盘价
    close_prices = [k["close"] for k in klines]
    
    # 计算当前 EMA
    current_ema = calculate_ema(close_prices, period)
    
    # 计算上一根 K 线的 EMA（用于判断交叉）
    prev_ema = calculate_ema(close_prices[:-1], period)
    
    current_price = close_prices[-1]
    
    # 判断趋势和信号
    if current_price > current_ema:
        trend = "上升趋势"
    else:
        trend = "下降趋势"
    
    # 判断交叉信号
    if close_prices[-2] <= prev_ema and current_price > current_ema:
        signal = "BUY"  # 金叉
    elif close_prices[-2] >= prev_ema and current_price < current_ema:
        signal = "SELL"  # 死叉
    else:
        signal = "HOLD"
    
    return {
        "symbol": symbol,
        "price": current_price,
        "ema": current_ema,
        "trend": trend,
        "signal": signal,
        "signal_strength": abs(current_price - current_ema) / current_ema * 100
    }

def calculate_position_size(entry_price: float, stop_loss: float, 
                           capital: float, risk_pct: float = 2.0) -> float:
    """计算仓位大小"""
    risk_amount = capital * (risk_pct / 100)
    price_risk = abs(entry_price - stop_loss)
    
    if price_risk == 0:
        return 0
    
    quantity = risk_amount / price_risk
    return quantity

# ============== 主程序 ==============

def main():
    """主函数 - 扫描所有交易对"""
    
    logger.info("=" * 50)
    logger.info("EMA10 趋势跟踪策略启动")
    logger.info("=" * 50)
    
    # 从配置获取参数
    symbols = config.get("parameters", {}).get("symbols", ["BTCUSDT"])
    ema_period = config.get("parameters", {}).get("ema_period", 10)
    stop_loss_pct = config.get("parameters", {}).get("stop_loss_pct", 2.0)
    take_profit_pct = config.get("parameters", {}).get("take_profit_pct", 5.0)
    
    logger.info(f"监控交易对: {symbols}")
    logger.info(f"EMA 周期: {ema_period}")
    logger.info(f"止损: {stop_loss_pct}% | 止盈: {take_profit_pct}%")
    logger.info("-" * 50)
    
    # 循环分析每个交易对
    while True:
        for symbol in symbols:
            try:
                result = get_ema_trend(symbol, ema_period)
                
                if result["signal"] != "N/A":
                    status = "📈" if result["signal"] == "BUY" else "📉" if result["signal"] == "SELL" else "⏸️"
                    
                    logger.info(
                        f"{status} {symbol}: ${result['price']:.2f} | "
                        f"EMA: ${result['ema']:.2f} | "
                        f"{result['trend']} | "
                        f"信号: {result['signal']}"
                    )
                    
                    # 如果有买入信号，打印详细建议
                    if result["signal"] == "BUY":
                        logger.info(
                            f"   💡 建议: 考虑做多 | "
                            f"止损: ${result['price'] * (1 - stop_loss_pct/100):.2f} | "
                            f"目标: ${result['price'] * (1 + take_profit_pct/100):.2f}"
                        )
                
                # 避免请求过快
                time.sleep(0.5)
                
            except Exception as e:
                logger.error(f"处理 {symbol} 时出错: {e}")
        
        logger.info("-" * 50)
        logger.info(f"扫描完成，下次扫描在 60 秒后... ({datetime.now().strftime('%H:%M:%S')})")
        
        # 等待 60 秒后再次扫描
        time.sleep(60)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        logger.info("策略已停止")
    except Exception as e:
        logger.error(f"程序异常退出: {e}")