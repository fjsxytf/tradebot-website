"""
支撑阻力突破策略 - Python 实盘版本
策略编号: 10
价格: $4.99 (进阶系列)
"""

import asyncio
import json
import logging
from dataclasses import dataclass
from typing import Optional, List, Tuple
import pandas as pd
import numpy as np

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class StrategyConfig:
    pivot_lookback: int = 10
    sr_levels: int = 3
    breakout_threshold: float = 0.005
    volume_multiplier: float = 1.5
    risk_per_trade: float = 0.02
    exchanges: List[str] = None
    
    def __post_init__(self):
        if self.exchanges is None:
            self.exchanges = ["hyperliquid"]


class SupportResistanceBreakout:
    """
    支撑阻力突破策略
    
    核心逻辑:
    1. 识别近期高低点作为动态支撑阻力位
    2. 价格突破 + 成交量放大 = 入场信号
    3. 假突破过滤：突破后回撤不超过阈值
    """
    
    def __init__(self, config: StrategyConfig):
        self.config = config
        self.position = 0
        self.data = pd.DataFrame()
        self.resistances: List[float] = []
        self.supports: List[float] = []
        self.recent_breakout = None  # 'up' or 'down'
        
    def find_pivots(self, series: pd.Series, lookback: int) -> pd.Series:
        """查找枢轴点"""
        pivots = pd.Series(index=series.index, dtype=float)
        
        for i in range(lookback, len(series) - lookback):
            window = series.iloc[i-lookback:i+lookback+1]
            if series.iloc[i] == window.max():
                pivots.iloc[i] = series.iloc[i]
            elif series.iloc[i] == window.min():
                pivots.iloc[i] = series.iloc[i]
        
        return pivots
    
    def update_sr_levels(self):
        """更新支撑阻力位"""
        if len(self.data) < self.config.pivot_lookback * 2 + 1:
            return
        
        # 查找高低点
        high_pivots = self.find_pivots(self.data['high'], self.config.pivot_lookback)
        low_pivots = self.find_pivots(self.data['low'], self.config.pivot_lookback)
        
        # 获取最近的枢轴点
        recent_highs = high_pivots.dropna().tail(self.config.sr_levels).values
        recent_lows = low_pivots.dropna().tail(self.config.sr_levels).values
        
        self.resistances = sorted(recent_highs, reverse=True) if len(recent_highs) > 0 else [self.data['high'].iloc[-1]]
        self.supports = sorted(recent_lows) if len(recent_lows) > 0 else [self.data['low'].iloc[-1]]
    
    def check_breakout(self) -> Tuple[bool, bool, bool]:
        """
        检查突破情况
        
        Returns:
            (breakout_up, breakout_down, is_fakeout)
        """
        if len(self.data) < 20:
            return False, False, False
        
        current_close = self.data['close'].iloc[-1]
        current_high = self.data['high'].iloc[-1]
        current_low = self.data['low'].iloc[-1]
        current_vol = self.data['volume'].iloc[-1] if 'volume' in self.data.columns else 0
        
        # 成交量检查
        vol_sma = self.data['volume'].rolling(20).mean().iloc[-1] if 'volume' in self.data.columns else 1
        high_volume = current_vol > vol_sma * self.config.volume_multiplier
        
        # 最近的支撑阻力
        nearest_r = self.resistances[0] if self.resistances else current_high
        nearest_s = self.supports[0] if self.supports else current_low
        
        # 突破检测
        breakout_up = current_close > nearest_r * (1 + self.config.breakout_threshold) and high_volume
        breakout_down = current_close < nearest_s * (1 - self.config.breakout_threshold) and high_volume
        
        # 假突破检测
        is_fakeout = False
        if self.recent_breakout == 'up' and current_close < nearest_r:
            is_fakeout = True
        elif self.recent_breakout == 'down' and current_close > nearest_s:
            is_fakeout = True
        
        # 记录突破
        if breakout_up:
            self.recent_breakout = 'up'
        elif breakout_down:
            self.recent_breakout = 'down'
        
        return breakout_up, breakout_down, is_fakeout
    
    def generate_signal(self) -> Optional[str]:
        """生成交易信号"""
        self.update_sr_levels()
        breakout_up, breakout_down, is_fakeout = self.check_breakout()
        
        if self.position == 0:
            if breakout_up and not is_fakeout:
                logger.info(f"🟢 突破阻力位做多 | 阻力: {self.resistances[0]:.2f}")
                return "long"
            elif breakout_down and not is_fakeout:
                logger.info(f"🔴 跌破支撑位做空 | 支撑: {self.supports[0]:.2f}")
                return "short"
        
        elif self.position == 1:
            # 检查是否回撤到原阻力位（现在变成支撑）
            if self.resistances and self.data['close'].iloc[-1] < self.resistances[0] * 0.995:
                logger.info("📕 价格回撤到原阻力位，平多仓")
                return "close_long"
        
        elif self.position == -1:
            if self.supports and self.data['close'].iloc[-1] > self.supports[0] * 1.005:
                logger.info("📗 价格反弹到原支撑位，平空仓")
                return "close_short"
        
        return None
    
    async def run(self):
        """主运行循环"""
        logger.info("=" * 50)
        logger.info("支撑阻力突破策略启动")
        logger.info(f"配置: 枢轴点周期{self.config.pivot_lookback}, 突破阈值{self.config.breakout_threshold*100:.1f}%")
        logger.info("=" * 50)
        
        while True:
            try:
                signal = self.generate_signal()
                if signal:
                    current_price = self.data['close'].iloc[-1] if len(self.data) > 0 else 0
                    if signal == "long":
                        self.position = 1
                        logger.info(f"🚀 开多仓 @ {current_price:.2f}")
                    elif signal == "short":
                        self.position = -1
                        logger.info(f"🚀 开空仓 @ {current_price:.2f}")
                    elif signal in ["close_long", "close_short"]:
                        self.position = 0
                        logger.info(f"🔒 平仓 @ {current_price:.2f}")
                
                await asyncio.sleep(60)
                
            except Exception as e:
                logger.error(f"策略运行错误: {e}")
                await asyncio.sleep(60)


def load_config(path: str) -> StrategyConfig:
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    pivot = data.get("indicators", {}).get("pivot_points", {})
    return StrategyConfig(
        pivot_lookback=pivot.get("lookback", 10),
        risk_per_trade=data.get("risk_management", {}).get("risk_per_trade", 0.02),
        exchanges=data.get("exchanges", ["hyperliquid"])
    )


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config.json")
    args = parser.parse_args()
    
    config = load_config(args.config)
    strategy = SupportResistanceBreakout(config)
    asyncio.run(strategy.run())
