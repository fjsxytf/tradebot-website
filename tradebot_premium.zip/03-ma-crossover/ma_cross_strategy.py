#!/usr/bin/env python3
"""
MA Crossover Strategy - Python Implementation
均线金叉死叉策略

作者: TradeBot
版本: 1.0
"""

import json
import time
import logging
from datetime import datetime
from typing import List, Dict

try:
    import requests
except ImportError:
    print("请先安装 requests: pip install requests")
    exit(1)

# ============== 配置区域 ==============
with open("config.json", "r", encoding="utf-8") as f:
    config = json.load(f)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('trading_log.txt', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

BINANCE_API_BASE = "https://api.binance.com/api/v3"

# ============== 工具函数 ==============

def get_klines(symbol: str, interval: str = "4h", limit: int = 200) -> List[Dict]:
    """获取 K 线数据"""
    url = f"{BINANCE_API_BASE}/klines"
    params = {"symbol": symbol, "interval": interval, "limit": limit}
    
    try:
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        klines = []
        for k in data:
            klines.append({
                "open": float(k[1]),
                "high": float(k[2]),
                "low": float(k[3]),
                "close": float(k[4]),
                "volume": float(k[5])
            })
        return klines
    except Exception as e:
        logger.error(f"获取 {symbol} K线数据失败: {e}")
        return []

def calculate_ma(prices: List[float], period: int, ma_type: str = "SMA") -> float:
    """计算均线"""
    if len(prices) < period:
        return 0.0
    
    if ma_type == "EMA":
        multiplier = 2 / (period + 1)
        ma = sum(prices[:period]) / period
        for price in prices[period:]:
            ma = (price - ma) * multiplier + ma
        return ma
    else:
        return sum(prices[-period:]) / period

def get_ma_cross_signal(symbol: str, fast_period: int = 10, 
                        slow_period: int = 30, 
                        ma_type: str = "SMA") -> Dict:
    """分析均线交叉信号"""
    klines = get_klines(symbol, interval="4h", limit=200)
    
    if len(klines) < slow_period + 2:
        return {"signal": "N/A", "status": "数据不足"}
    
    close_prices = [k["close"] for k in klines]
    
    # 计算当前均线
    current_fast = calculate_ma(close_prices, fast_period, ma_type)
    current_slow = calculate_ma(close_prices, slow_period, ma_type)
    
    # 计算前一根 K 线的均线
    prev_fast = calculate_ma(close_prices[:-1], fast_period, ma_type)
    prev_slow = calculate_ma(close_prices[:-1], slow_period, ma_type)
    
    current_price = close_prices[-1]
    
    # 判断交叉信号
    if prev_fast <= prev_slow and current_fast > current_slow:
        signal = "GOLDEN_CROSS"  # 金叉
    elif prev_fast >= prev_slow and current_fast < current_slow:
        signal = "DEATH_CROSS"   # 死叉
    elif current_fast > current_slow:
        signal = "BULLISH"       # 多头排列
    else:
        signal = "BEARISH"       # 空头排列
    
    # 判断趋势
    if current_fast > current_slow:
        trend = "上升趋势 ↑"
    else:
        trend = "下降趋势 ↓"
    
    return {
        "symbol": symbol,
        "price": current_price,
        "fast_ma": current_fast,
        "slow_ma": current_slow,
        "signal": signal,
        "trend": trend,
        "gap_pct": abs(current_fast - current_slow) / current_slow * 100
    }

def get_recommendation(signal: str, price: float, 
                       stop_pct: float, profit_pct: float) -> str:
    """获取交易建议"""
    if signal == "GOLDEN_CROSS":
        stop = price * (1 - stop_pct/100)
        target = price * (1 + profit_pct/100)
        return f"⚠️ 金叉确认！建议买入 | 止损: ${stop:.2f} | 目标: ${target:.2f}"
    elif signal == "DEATH_CROSS":
        return "⚠️ 死叉出现！建议卖出/平仓"
    elif signal == "BULLISH":
        return "多头排列中，持有或逢低买入"
    else:
        return "空头排列中，建议观望"

# ============== 主程序 ==============

def main():
    """主函数"""
    
    logger.info("=" * 50)
    logger.info("均线金叉死叉策略启动")
    logger.info("=" * 50)
    
    symbols = config.get("parameters", {}).get("symbols", ["BTCUSDT"])
    fast_period = config.get("parameters", {}).get("fast_ma_period", 10)
    slow_period = config.get("parameters", {}).get("slow_ma_period", 30)
    ma_type = config.get("parameters", {}).get("ma_type", "SMA")
    
    logger.info(f"监控交易对: {symbols}")
    logger.info(f"快速均线: {ma_type}{fast_period} | 慢速均线: {ma_type}{slow_period}")
    logger.info("-" * 50)
    
    while True:
        for symbol in symbols:
            try:
                result = get_ma_cross_signal(symbol, fast_period, slow_period, ma_type)
                
                if result["signal"] != "N/A":
                    icon = "🟢" if "GOLDEN" in result["signal"] else \
                           "🔴" if "DEATH" in result["signal"] else "⚪"
                    
                    logger.info(
                        f"{icon} {symbol}: ${result['price']:.2f} | "
                        f"{result.get('fast_ma', 0):.2f}/{result.get('slow_ma', 0):.2f} | "
                        f"{result['trend']} | "
                        f"信号: {result['signal']}"
                    )
                    
                    if result["signal"] in ["GOLDEN_CROSS", "DEATH_CROSS"]:
                        logger.info(
                            f"   💡 {get_recommendation(result['signal'], result['price'], 2.5, 5.0)}"
                        )
                
                time.sleep(0.5)
                
            except Exception as e:
                logger.error(f"处理 {symbol} 时出错: {e}")
        
        logger.info("-" * 50)
        logger.info(f"扫描完成，下次扫描在 60 秒后... ({datetime.now().strftime('%H:%M:%S')})")
        time.sleep(60)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        logger.info("策略已停止")
    except Exception as e:
        logger.error(f"程序异常退出: {e}")