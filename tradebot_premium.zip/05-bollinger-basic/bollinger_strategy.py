#!/usr/bin/env python3
"""
Bollinger Bands Strategy - Python Implementation
布林带基础策略

作者: TradeBot
版本: 1.0
"""

import json
import time
import logging
from datetime import datetime
from typing import List, Dict

try:
    import requests
except ImportError:
    print("请先安装 requests: pip install requests")
    exit(1)

# ============== 配置区域 ==============
with open("config.json", "r", encoding="utf-8") as f:
    config = json.load(f)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('trading_log.txt', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

BINANCE_API_BASE = "https://api.binance.com/api/v3"

# ============== 工具函数 ==============

def get_klines(symbol: str, interval: str = "4h", limit: int = 200) -> List[Dict]:
    """获取 K 线数据"""
    url = f"{BINANCE_API_BASE}/klines"
    params = {"symbol": symbol, "interval": interval, "limit": limit}
    
    try:
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        klines = []
        for k in data:
            klines.append({
                "open": float(k[1]),
                "high": float(k[2]),
                "low": float(k[3]),
                "close": float(k[4]),
                "volume": float(k[5])
            })
        return klines
    except Exception as e:
        logger.error(f"获取 {symbol} K线数据失败: {e}")
        return []

def calculate_bollinger_bands(prices: List[float], period: int = 20, 
                              std_dev: float = 2.0) -> Dict:
    """计算布林带"""
    if len(prices) < period:
        return {"upper": 0, "middle": 0, "lower": 0, "bandwidth": 0}
    
    # 计算中轨（SMA）
    middle = sum(prices[-period:]) / period
    
    # 计算标准差
    variance = sum((p - middle) ** 2 for p in prices[-period:]) / period
    std = variance ** 0.5
    
    upper = middle + (std_dev * std)
    lower = middle - (std_dev * std)
    
    # 计算布林带宽度（用于判断波动率）
    bandwidth = (upper - lower) / middle * 100
    
    return {
        "upper": upper,
        "middle": middle,
        "lower": lower,
        "bandwidth": bandwidth
    }

def get_bb_signal(symbol: str, period: int = 20, std_dev: float = 2.0) -> Dict:
    """分析布林带信号"""
    klines = get_klines(symbol, interval="4h", limit=200)
    
    if len(klines) < period + 2:
        return {"signal": "N/A", "status": "数据不足"}
    
    close_prices = [k["close"] for k in klines]
    
    # 计算当前布林带
    current = calculate_bollinger_bands(close_prices, period, std_dev)
    
    # 计算前一根布林带
    prev = calculate_bollinger_bands(close_prices[:-1], period, std_dev)
    
    current_price = close_prices[-1]
    
    # 判断信号
    if current_price <= current["lower"]:
        signal = "LOWER_TOUCH"  # 触及下轨
    elif current_price >= current["upper"]:
        signal = "UPPER_TOUCH"  # 触及上轨
    elif prev["price"] < prev["lower"] and current_price > current["lower"]:
        signal = "BREAK_LOWER"  # 突破下轨
    elif prev["price"] < prev["middle"] and current_price > current["middle"]:
        signal = "BREAK_MIDDLE"  # 突破中轨
    else:
        signal = "NEUTRAL"
    
    # 计算 %B（价格在布林带中的位置）
    if current["upper"] != current["lower"]:
        percent_b = (current_price - current["lower"]) / (current["upper"] - current["lower"]) * 100
    else:
        percent_b = 50
    
    return {
        "symbol": symbol,
        "price": current_price,
        "upper": current["upper"],
        "middle": current["middle"],
        "lower": current["lower"],
        "bandwidth": current["bandwidth"],
        "percent_b": percent_b,
        "signal": signal
    }

def get_recommendation(signal: str, price: float, bb: Dict,
                       stop_pct: float, profit_pct: float) -> str:
    """获取交易建议"""
    if signal == "LOWER_TOUCH":
        stop = price * (1 - stop_pct/100)
        target = price * (1 + profit_pct/100)
        return f"触及下轨！买入 | 止损: ${stop:.2f} | 目标: ${target:.2f}"
    elif signal == "UPPER_TOUCH":
        return "触及上轨！卖出/平仓"
    elif signal == "BREAK_MIDDLE":
        return f"突破中轨 ${bb['middle']:.2f}，确认上升趋势"
    elif signal == "BREAK_LOWER":
        return "跌破下轨，等待反弹确认"
    return f"%B: {bb['percent_b']:.1f}% | 观望"

# ============== 主程序 ==============

def main():
    """主函数"""
    
    logger.info("=" * 50)
    logger.info("布林带基础策略启动")
    logger.info("=" * 50)
    
    symbols = config.get("parameters", {}).get("symbols", ["BTCUSDT"])
    bb_period = config.get("parameters", {}).get("bb_period", 20)
    bb_std = config.get("parameters", {}).get("bb_std", 2.0)
    
    logger.info(f"监控交易对: {symbols}")
    logger.info(f"布林带参数: 周期={bb_period}, 标准差={bb_std}")
    logger.info("-" * 50)
    
    while True:
        for symbol in symbols:
            try:
                result = get_bb_signal(symbol, bb_period, bb_std)
                
                if result["signal"] != "N/A":
                    icon = "🟢" if "LOWER" in result["signal"] else \
                           "🔴" if "UPPER" in result["signal"] else "⚪"
                    
                    logger.info(
                        f"{icon} {symbol}: ${result['price']:.2f} | "
                        f"上轨: ${result['upper']:.2f} | "
                        f"中轨: ${result['middle']:.2f} | "
                        f"下轨: ${result['lower']:.2f}"
                    )
                    logger.info(
                        f"   %B: {result['percent_b']:.1f}% | "
                        f"带宽: {result['bandwidth']:.2f}% | "
                        f"信号: {result['signal']}"
                    )
                    
                    logger.info(f"   💡 {get_recommendation(result['signal'], result['price'], result, 3.0, 6.0)}")
                
                time.sleep(0.5)
                
            except Exception as e:
                logger.error(f"处理 {symbol} 时出错: {e}")
        
        logger.info("-" * 50)
        logger.info(f"扫描完成，下次扫描在 60 秒后... ({datetime.now().strftime('%H:%M:%S')})")
        time.sleep(60)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        logger.info("策略已停止")
    except Exception as e:
        logger.error(f"程序异常退出: {e}")