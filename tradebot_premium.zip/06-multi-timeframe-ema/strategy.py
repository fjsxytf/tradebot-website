"""
多时间框架 EMA 策略 - Python 实盘版本
策略编号: 06
价格: $4.99 (进阶系列)
"""

import asyncio
import json
import logging
from dataclasses import dataclass
from typing import Optional, Dict, List
import pandas as pd
import numpy as np

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class StrategyConfig:
    """策略配置"""
    ema_fast: int = 10
    ema_slow: int = 20
    risk_per_trade: float = 0.02
    exchanges: List[str] = None
    
    def __post_init__(self):
        if self.exchanges is None:
            self.exchanges = ["hyperliquid"]


class MultiTimeframeEMA:
    """
    多时间框架 EMA 策略
    
    核心逻辑:
    1. 同时监控 1h、4h、1d 三个时间框架
    2. 只有当三个时间框架的 EMA 排列一致时才开仓
    3. 1h 级别价格跌破/突破 EMA 时平仓
    """
    
    def __init__(self, config: StrategyConfig):
        self.config = config
        self.position = 0  # 0: 无仓位, 1: 多仓, -1: 空仓
        self.data_1h = pd.DataFrame()
        self.data_4h = pd.DataFrame()
        self.data_1d = pd.DataFrame()
        
    def calculate_ema(self, data: pd.Series, period: int) -> pd.Series:
        """计算 EMA"""
        return data.ewm(span=period, adjust=False).mean()
    
    def analyze_timeframe(self, df: pd.DataFrame, tf: str) -> Dict:
        """分析单个时间框架"""
        if len(df) < self.config.ema_slow:
            return {"valid": False}
        
        ema_fast = self.calculate_ema(df['close'], self.config.ema_fast)
        ema_slow = self.calculate_ema(df['close'], self.config.ema_slow)
        
        latest_close = df['close'].iloc[-1]
        latest_fast = ema_fast.iloc[-1]
        latest_slow = ema_slow.iloc[-1]
        
        return {
            "valid": True,
            "close": latest_close,
            "ema_fast": latest_fast,
            "ema_slow": latest_slow,
            "bullish": latest_close > latest_fast > latest_slow,
            "bearish": latest_close < latest_fast < latest_slow,
            "direction_up": latest_fast > latest_slow
        }
    
    def generate_signal(self) -> Optional[str]:
        """
        生成交易信号
        
        Returns:
            'long' - 做多信号
            'short' - 做空信号
            'close_long' - 平多仓
            'close_short' - 平空仓
            None - 无信号
        """
        # 分析三个时间框架
        tf_1h = self.analyze_timeframe(self.data_1h, "1h")
        tf_4h = self.analyze_timeframe(self.data_4h, "4h")
        tf_1d = self.analyze_timeframe(self.data_1d, "1d")
        
        if not all([tf_1h.get("valid"), tf_4h.get("valid"), tf_1d.get("valid")]):
            return None
        
        # 检查是否满足多时间框架多头排列
        multi_bullish = (
            tf_1h["bullish"] and 
            tf_4h["ema_fast"] > tf_4h["ema_slow"] and 
            tf_1d["direction_up"]
        )
        
        # 检查是否满足多时间框架空头排列
        multi_bearish = (
            tf_1h["bearish"] and 
            tf_4h["ema_fast"] < tf_4h["ema_slow"] and 
            not tf_1d["direction_up"]
        )
        
        # 当前持仓状态
        if self.position == 0:
            # 无仓位，检查开仓信号
            if multi_bullish:
                logger.info(f"🟢 多时间框架多头排列形成 | 1h: {tf_1h['close']:.2f}")
                return "long"
            elif multi_bearish:
                logger.info(f"🔴 多时间框架空头排列形成 | 1h: {tf_1h['close']:.2f}")
                return "short"
        
        elif self.position == 1:
            # 持有多仓，检查平仓信号
            if tf_1h["close"] < tf_1h["ema_fast"]:
                logger.info(f"📕 平多仓信号 | 价格跌破1h EMA")
                return "close_long"
        
        elif self.position == -1:
            # 持有空仓，检查平仓信号
            if tf_1h["close"] > tf_1h["ema_fast"]:
                logger.info(f"📗 平空仓信号 | 价格突破1h EMA")
                return "close_short"
        
        return None
    
    def execute_signal(self, signal: str, price: float):
        """执行交易信号"""
        if signal == "long":
            self.position = 1
            logger.info(f"🚀 开多仓 @ {price:.2f}")
        elif signal == "short":
            self.position = -1
            logger.info(f"🚀 开空仓 @ {price:.2f}")
        elif signal in ["close_long", "close_short"]:
            pnl = "盈利" if (self.position == 1 and price > self.entry_price) or \
                           (self.position == -1 and price < self.entry_price) else "亏损"
            logger.info(f"🔒 平仓 @ {price:.2f} | 结果: {pnl}")
            self.position = 0
    
    async def run(self):
        """主运行循环"""
        logger.info("=" * 50)
        logger.info("多时间框架 EMA 策略启动")
        logger.info(f"配置: EMA({self.config.ema_fast}/{self.config.ema_slow})")
        logger.info("=" * 50)
        
        while True:
            try:
                # 这里应该调用交易所 API 获取数据
                # 示例：self.data_1h = await exchange.get_ohlcv("BTC-USD", "1h")
                # 示例：self.data_4h = await exchange.get_ohlcv("BTC-USD", "4h")
                # 示例：self.data_1d = await exchange.get_ohlcv("BTC-USD", "1d")
                
                signal = self.generate_signal()
                if signal:
                    current_price = self.data_1h['close'].iloc[-1]
                    self.execute_signal(signal, current_price)
                
                # 每分钟检查一次
                await asyncio.sleep(60)
                
            except Exception as e:
                logger.error(f"策略运行错误: {e}")
                await asyncio.sleep(60)


def load_config(path: str) -> StrategyConfig:
    """加载配置文件"""
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    return StrategyConfig(
        ema_fast=data.get("indicators", {}).get("ema_fast", {}).get("period", 10),
        ema_slow=data.get("indicators", {}).get("ema_slow", {}).get("period", 20),
        risk_per_trade=data.get("risk_management", {}).get("risk_per_trade", 0.02),
        exchanges=data.get("exchanges", ["hyperliquid"])
    )


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="多时间框架 EMA 策略")
    parser.add_argument("--config", default="config.json", help="配置文件路径")
    args = parser.parse_args()
    
    # 加载配置
    config = load_config(args.config)
    
    # 创建策略实例
    strategy = MultiTimeframeEMA(config)
    
    # 运行策略
    asyncio.run(strategy.run())
