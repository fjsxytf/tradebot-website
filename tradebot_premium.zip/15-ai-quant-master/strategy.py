"""
套餐 15：AI 量化全能包 (AI Quant Master)
交易所：Hyperliquid / Binance / OKX
ML 模型：SVM + Random Forest 組合預測
多策略：EMA + RSI + Bollinger + Supertrend 投票
"""

import json
import time
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Tuple

# === 核心依賴 ===
# pip install ccxt pandas numpy scikit-learn joblib

try:
    import ccxt
    import pandas as pd
    import numpy as np
    from sklearn.svm import SVC
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import accuracy_score
    from joblib import dump, load
    HAS_ML = True
except ImportError:
    HAS_ML = False
    print("⚠️  缺少依賴，請運行：pip install ccxt pandas numpy scikit-learn joblib")

# === 日誌配置 ===
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("ai_quant.log", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("AIQuantMaster")


# ═══════════════════════════════════════════════════════════════════
# 配置類
# ═══════════════════════════════════════════════════════════════════

class AIQuantConfig:
    """AI 量化全能包配置"""

    def __init__(self, config_path: str = None):
        if config_path and os.path.exists(config_path):
            with open(config_path, "r", encoding="utf-8") as f:
                cfg = json.load(f)
        else:
            cfg = self._default_config()

        params = cfg.get("parameters", cfg)

        self.symbol = cfg.get("symbol", "BTC/USDT")
        self.timeframe = cfg.get("timeframe", "1h")
        self.ml_model_type = params.get("ml_model_type", "random_forest")
        self.train_window_days = params.get("train_window_days", 365)
        self.confidence_threshold = params.get("confidence_threshold", 0.65)
        self.signal_vote_threshold = params.get("signal_vote_threshold", 3)
        self.max_position_pct = params.get("max_position_pct", 0.2)
        self.atr_period = params.get("atr_period", 14)
        self.risk_reward_ratio = params.get("risk_reward_ratio", 2.0)
        self.daily_retrain = params.get("daily_retrain", True)
        self.telegram_alerts = params.get("telegram_alerts", True)
        self.tg_token = cfg.get("tg_token", "")
        self.tg_chat_id = cfg.get("tg_chat_id", "")

    @staticmethod
    def _default_config():
        return {
            "symbol": "BTC/USDT",
            "timeframe": "1h",
            "parameters": {
                "ml_model_type": "random_forest",
                "train_window_days": 365,
                "confidence_threshold": 0.65,
                "signal_vote_threshold": 3,
                "max_position_pct": 0.2,
                "atr_period": 14,
                "risk_reward_ratio": 2.0,
                "daily_retrain": True,
                "telegram_alerts": True
            }
        }


# ═══════════════════════════════════════════════════════════════════
# 特徵工程
# ═══════════════════════════════════════════════════════════════════

class FeatureEngineer:
    """技術指標特徵構建"""

    @staticmethod
    def add_features(df: pd.DataFrame) -> pd.DataFrame:
        """添加 20+ 技術特徵"""
        close = df["close"]
        high = df["high"]
        low = df["low"]
        volume = df["volume"]

        # 1. EMA 特徵
        ema10 = df["ema10"] = ta_ema(close, 10)
        ema21 = df["ema21"] = ta_ema(close, 21)
        df["ema_diff_pct"] = (ema10 - ema21) / ema21 * 100

        # 2. RSI
        df["rsi"] = ta_rsi(close, 14)

        # 3. MACD
        df["macd"], df["macd_signal"], df["macd_hist"] = ta_macd(close, 12, 26, 9)
        df["macd_hist_change"] = df["macd_hist"].diff()

        # 4. 布林帶
        bb_mid, bb_up, bb_dn = ta_bb(close, 20, 2)
        df["bb_pos"] = (close - bb_dn) / (bb_up - bb_dn)
        df["bb_width"] = (bb_up - bb_dn) / bb_mid

        # 5. ATR
        df["atr"] = ta_atr(high, low, close, 14)
        df["atr_pct"] = df["atr"] / close * 100

        # 6. 成交量特徵
        df["vol_ma"] = volume.rolling(20).mean()
        df["vol_ratio"] = volume / df["vol_ma"]
        df["vol_change"] = volume.pct_change()

        # 7. 價格動量
        df["return_1"] = close.pct_change(1)
        df["return_3"] = close.pct_change(3)
        df["return_5"] = close.pct_change(5)
        df["return_10"] = close.pct_change(10)

        # 8. 超級趨勢
        df["supertrend"], df["st_dir"] = ta_supertrend(high, low, close, 3.0, 10)

        # 9. 支撐/阻力
        df["support"] = low.rolling(20).min()
        df["resistance"] = high.rolling(20).max()
        df["sr_pos"] = (close - df["support"]) / (df["resistance"] - df["support"])

        return df.dropna()

    @staticmethod
    def build_label(df: pd.DataFrame, lookforward: int = 24) -> pd.DataFrame:
        """
        構建標籤：未來 lookforward 根 K 線的收益率
        標籤：1=看多（收益>0.5%），-1=看空（收益<-0.5%），0=觀望
        """
        future_ret = df["close"].shift(-lookforward) / df["close"] - 1
        df["label"] = np.where(future_ret > 0.005, 1, np.where(future_ret < -0.005, -1, 0))
        return df.dropna()


# ═══════════════════════════════════════════════════════════════════
# 技術指標計算（純 NumPy/Pandas 實現）
# ═══════════════════════════════════════════════════════════════════

def ta_ema(series: pd.Series, period: int) -> pd.Series:
    return series.ewm(span=period, adjust=False).mean()

def ta_rsi(series: pd.Series, period: int) -> pd.Series:
    delta = series.diff()
    gain = delta.where(delta > 0, 0).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    return 100 - (100 / (1 + rs))

def ta_macd(close: pd.Series, fast: int, slow: int, signal: int) -> Tuple[pd.Series, pd.Series, pd.Series]:
    ema_fast = ta_ema(close, fast)
    ema_slow = ta_ema(close, slow)
    macd = ema_fast - ema_slow
    signal_line = ta_ema(macd, signal)
    hist = macd - signal_line
    return macd, signal_line, hist

def ta_bb(close: pd.Series, period: int, std: float) -> Tuple[pd.Series, pd.Series, pd.Series]:
    mid = close.rolling(window=period).mean()
    std_dev = close.rolling(window=period).std()
    upper = mid + (std_dev * std)
    lower = mid - (std_dev * std)
    return mid, upper, lower

def ta_atr(high: pd.Series, low: pd.Series, close: pd.Series, period: int) -> pd.Series:
    tr = pd.concat([
        high - low,
        (high - close.shift(1)).abs(),
        (low - close.shift(1)).abs()
    ], axis=1).max(axis=1)
    return tr.rolling(window=period).mean()

def ta_supertrend(high: pd.Series, low: pd.Series, close: pd.Series,
                  atr_mult: float, atr_period: int) -> Tuple[pd.Series, pd.Series]:
    atr = ta_atr(high, low, close, atr_period)
    hl2 = (high + low) / 2
    upper = hl2 + atr_mult * atr
    lower = hl2 - atr_mult * atr

    st = pd.Series(index=close.index, dtype=float)
    direction = pd.Series(index=close.index, dtype=float)

    dir_val = 1
    st_val = lower.iloc[0]

    for i in range(len(close)):
        if dir_val == 1:            st_val = lower.iloc[i]
            if close.iloc[i] < upper.iloc[i]:
                dir_val = -1
                st_val = upper.iloc[i]
        else:
            st_val = upper.iloc[i]
            if close.iloc[i] > lower.iloc[i]:
                dir_val = 1
                st_val = lower.iloc[i]
        st.iloc[i] = st_val
        direction.iloc[i] = dir_val

    return st, direction


# ═══════════════════════════════════════════════════════════════════
# ML 模型
# ═══════════════════════════════════════════════════════════════════

class MLModel:
    """機器學習價格預測模型"""

    FEATURE_COLS = [
        "ema_diff_pct", "rsi", "macd_hist", "macd_hist_change",
        "bb_pos", "bb_width", "atr_pct", "vol_ratio", "vol_change",
        "return_1", "return_3", "return_5", "return_10", "sr_pos"
    ]

    def __init__(self, model_type: str = "random_forest"):
        self.model_type = model_type
        self.model = None
        self.scaler = StandardScaler()
        self.accuracy = 0.0

    def train(self, df: pd.DataFrame) -> None:
        """訓練模型"""
        if not HAS_ML:
            raise RuntimeError("缺少 scikit-learn")

        # 準備特徵和標籤
        X = df[self.FEATURE_COLS].values
        y = df["label"].values

        # 去除觀望標籤（標籤=0）
        mask = y != 0
        X = X[mask]
        y = y[mask]

        if len(X) < 100:
            logger.warning("訓練樣本不足 100 條，模型可能不準確")
            return

        # 標準化
        X_scaled = self.scaler.fit_transform(X)

        # 訓練模型
        if self.model_type == "svm":
            self.model = SVC(probability=True, kernel="rbf", C=1.0, gamma="auto")
        else:  # random_forest
            self.model = RandomForestClassifier(n_estimators=100, max_depth=10, random_state=42)

        self.model.fit(X_scaled, y)
        self.accuracy = accuracy_score(y, self.model.predict(X_scaled))
        logger.info(f"模型訓練完成：類型={self.model_type}, 準確度={self.accuracy*100:.1f}%")

    def predict(self, df: pd.DataFrame) -> Tuple[int, float]:
        """
        預測次日方向
        返回：(方向 1=多/-1=空, 置信度 0-1)
        """
        if self.model is None:
            logger.warning("模型未訓練，返回默認值")
            return 0, 0.5

        X = df[self.FEATURE_COLS].iloc[-1:].values
        X_scaled = self.scaler.transform(X)

        if self.model_type == "svm":
            proba = self.model.predict_proba(X_scaled)[0]
            # proba 順序：[label=-1, label=1] 或 [label=0, label=1] 需檢查
            classes = self.model.classes_
            if -1 in classes and 1 in classes:
                idx_neg = list(classes).index(-1)
                idx_pos = list(classes).index(1)
                conf_neg = proba[idx_neg]
                conf_pos = proba[idx_pos]
            else:
                conf_pos = proba[1] if len(proba) > 1 else 0.5
                conf_neg = 1 - conf_pos
        else:  # random_forest
            proba = self.model.predict_proba(X_scaled)[0]
            classes = self.model.classes_
            if -1 in classes and 1 in classes:
                idx_neg = list(classes).index(-1)
                idx_pos = list(classes).index(1)
                conf_neg = proba[idx_neg]
                conf_pos = proba[idx_pos]
            else:
                conf_pos = proba[1] if len(proba) > 1 else 0.5
                conf_neg = 1 - conf_pos

        if conf_pos > conf_neg and conf_pos > 0.5:
            return 1, conf_pos
        elif conf_neg > conf_pos and conf_neg > 0.5:
            return -1, conf_neg
        else:
            return 0, max(conf_pos, conf_neg)

    def save(self, path: str) -> None:
        if self.model:
            dump({"model": self.model, "scaler": self.scaler}, path)
            logger.info(f"模型已保存：{path}")

    def load(self, path: str) -> None:
        data = load(path)
        self.model = data["model"]
        self.scaler = data["scaler"]
        logger.info(f"模型已加載：{path}")


# ═══════════════════════════════════════════════════════════════════
# 子策略
# ═══════════════════════════════════════════════════════════════════

class SubStrategies:
    """四個子策略的信號生成"""

    @staticmethod
    def ema_signal(df: pd.DataFrame) -> int:
        """EMA 趨勢策略（套餐 01）"""
        if "ema10" not in df.columns:
            df["ema10"] = ta_ema(df["close"], 10)
            df["ema21"] = ta_ema(df["close"], 21)
        ema10 = df["ema10"].iloc[-1]
        ema21 = df["ema21"].iloc[-1]
        ema10_prev = df["ema10"].iloc[-2]
        ema21_prev = df["ema21"].iloc[-2]

        if ema10 > ema21 and ema10_prev <= ema21_prev:
            return 1
        elif ema10 < ema21 and ema10_prev >= ema21_prev:
            return -1
        return 0

    @staticmethod
    def rsi_signal(df: pd.DataFrame) -> int:
        """RSI 超買超賣策略（套餐 02）"""
        rsi = ta_rsi(df["close"], 14).iloc[-1]
        rsi_prev = ta_rsi(df["close"], 14).iloc[-2]
        if rsi < 30 and rsi_prev >= 30:
            return 1
        elif rsi > 70 and rsi_prev <= 70:
            return -1
        return 0

    @staticmethod
    def bb_signal(df: pd.DataFrame) -> int:
        """布林帶均值回歸策略（套餐 05）"""
        _, bb_up, bb_dn = ta_bb(df["close"], 20, 2)
        close = df["close"].iloc[-1]
        close_prev = df["close"].iloc[-2]
        if close < bb_dn.iloc[-1] and close_prev >= bb_dn.iloc[-2]:
            return 1
        elif close > bb_up.iloc[-1] and close_prev <= bb_up.iloc[-2]:
            return -1
        return 0

    @staticmethod
    def supertrend_signal(df: pd.DataFrame) -> int:
        """超級趨勢策略（套餐 11）"""
        if "st_dir" not in df.columns:
            _, df["st_dir"] = ta_supertrend(df["high"], df["low"], df["close"], 3.0, 10)
        st_dir = df["st_dir"].iloc[-1]
        st_dir_prev = df["st_dir"].iloc[-2]
        if st_dir == 1 and st_dir_prev == -1:
            return 1
        elif st_dir == -1 and st_dir_prev == 1:
            return -1
        return 0

    @classmethod
    def all_votes(cls, df: pd.DataFrame) -> int:
        """四策略投票，返回總票數（-4 到 +4）"""
        return (cls.ema_signal(df) + cls.rsi_signal(df) +
                cls.bb_signal(df) + cls.supertrend_signal(df))


# ═══════════════════════════════════════════════════════════════════
# 主策略類
# ═══════════════════════════════════════════════════════════════════

class AIQuantStrategy:
    """AI 量化全能策略"""

    MODEL_PATH = "models/ai_quant_model.joblib"

    def __init__(self, exchange_name: str, config: AIQuantConfig,
                 api_key: str = None, api_secret: str = None):
        if not HAS_ML:
            raise RuntimeError("缺少依賴包")

        self.config = config
        self.symbol = config.symbol
        self.tf = config.timeframe

        # 初始化交易所
        if exchange_name == "hyperliquid":
            self.exchange = ccxt.hyperliquid({
                "enableRateLimit": True,
                "options": {"defaultType": "swap"}
            })
        elif exchange_name == "binance":
            self.exchange = ccxt.binance({"enableRateLimit": True})
        elif exchange_name == "okx":
            self.exchange = ccxt.okx({"enableRateLimit": True})
        else:
            raise ValueError(f"不支持的交易所：{exchange_name}")

        if api_key and api_secret:
            self.exchange.apiKey = api_key
            self.exchange.secret = api_secret

        # ML 模型
        self.ml = MLModel(config.ml_model_type)
        self._ensure_model_dir()

        # 狀態
        self.position = 0
        self.entry_price = 0.0
        self.last_train_date = None

        logger.info(f"AI 量化策略初始化：交易所={exchange_name}, 品種={self.symbol}")

    def _ensure_model_dir(self):
        import os
        os.makedirs("models", exist_ok=True)

    def load_data(self, limit: int = 1000) -> pd.DataFrame:
        """從交易所加載 K 線數據"""
        logger.info(f"正在獲取 K 線數據 (limit={limit})...")
        ohlcv = self.exchange.fetch_ohlcv(self.symbol, self.tf, limit=limit)
        df = pd.DataFrame(ohlcv, columns=["timestamp", "open", "high", "low", "close", "volume"])
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")
        df.set_index("timestamp", inplace=True)
        return df

    def prepare_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """數據預處理：添加特徵和標籤"""
        df = FeatureEngineer.add_features(df)
        df = FeatureEngineer.build_label(df, lookforward=24)
        return df

    def retrain_if_needed(self, df: pd.DataFrame) -> None:
        """按需重新訓練模型（每日一次）"""
        today = datetime.now().date()
        if not self.config.daily_retrain:
            return
        if self.last_train_date == today:
            return

        logger.info("開始重新訓練模型...")
        train_days = self.config.train_window_days
        cutoff = datetime.now() - timedelta(days=train_days)
        train_df = df[df.index >= cutoff].copy()

        if len(train_df) < 200:
            logger.warning("訓練數據不足，跳過重新訓練")
            return

        self.ml.train(train_df)
        self.ml.save(self.MODEL_PATH)
        self.last_train_date = today

    def generate_signal(self, df: pd.DataFrame) -> Tuple[int, float, int]:
        """
        生成綜合信號
        返回：(方向 1/-1/0, ML置信度, 投票數)
        """
        # 1. 子策略投票
        votes = SubStrategies.all_votes(df)

        # 2. ML 預測
        ml_dir, ml_conf = self.ml.predict(df)

        # 3. 綜合判斷
        if votes >= self.config.signal_vote_threshold and ml_dir == 1 and ml_conf >= self.config.confidence_threshold:
            return 1, ml_conf, votes
        elif votes <= -self.config.signal_vote_threshold and ml_dir == -1 and ml_conf >= self.config.confidence_threshold:
            return -1, ml_conf, votes
        return 0, ml_conf, votes

    def calculate_sl_tp(self, entry: float, direction: int) -> Tuple[float, float]:
        """計算止損/止盈價"""
        atr = ta_atr(df["high"], df["low"], df["close"], self.config.atr_period).iloc[-1]
        if direction == 1:  # 多頭
            sl = entry - atr * 1.5
            tp = entry + atr * 1.5 * self.config.risk_reward_ratio
        else:  # 空頭
            sl = entry + atr * 1.5
            tp = entry - atr * 1.5 * self.config.risk_reward_ratio
        return sl, tp

    def send_telegram(self, message: str) -> None:
        """發送 Telegram 通知"""
        if not self.config.telegram_alerts or not self.config.tg_token:
            return
        try:
            import requests
            url = f"https://api.telegram.org/bot{self.config.tg_token}/sendMessage"
            payload = {"chat_id": self.config.tg_chat_id, "text": message, "parse_mode": "HTML"}
            requests.post(url, json=payload, timeout=10)
        except Exception as e:
            logger.error(f"Telegram 發送失敗：{e}")

    def run_backtest(self, df: pd.DataFrame) -> dict:
        """歷史回測"""
        df = self.prepare_data(df)

        # 訓練初始模型（使用前 30% 數據）
        train_size = int(len(df) * 0.3)
        train_df = df.iloc[:train_size]
        self.ml.train(train_df)
        logger.info(f"回測訓練完成，訓練樣本：{len(train_df)}")

        capital = 10000.0
        position = 0.0
        entry = 0.0
        trades = []
        equity = []

        for i in range(train_size, len(df)):
            row = df.iloc[i]
            # 使用截至當前的所有數據重新訓練（模擬每日訓練）
            if self.config.daily_retrain and i % 24 == 0:
                retrain_df = df.iloc[max(0, i-2000):i]
                self.ml.train(retrain_df)

            signal, conf, votes = self.generate_signal(df.iloc[:i+1])

            if signal == 1 and position == 0:
                entry = row["close"]
                position = capital / entry * self.config.max_position_pct
            elif signal == -1 and position > 0:
                exit_price = row["close"]
                pnl = (exit_price - entry) * position
                capital += pnl
                trades.append({"entry": entry, "exit": exit_price, "pnl": pnl, "dir": "long"})
                position = 0

            cur_val = capital + position * row["close"] if position > 0 else capital
            equity.append(cur_val)

        win_trades = [t for t in trades if t["pnl"] > 0]
        return {
            "total_trades": len(trades),
            "win_trades": len(win_trades),
            "win_rate": len(win_trades) / len(trades) if trades else 0,
            "total_pnl": sum(t["pnl"] for t in trades),
            "final_equity": equity[-1] if equity else capital,
            "max_drawdown": self._max_drawdown(equity),
        }

    @staticmethod
    def _max_drawdown(equity: list) -> float:
        peak = equity[0] if equity else 0
        max_dd = 0.0
        for v in equity:
            if v > peak:
                peak = v
            dd = (peak - v) / peak
            if dd > max_dd:
                max_dd = dd
        return max_dd

    def live_run(self, poll_seconds: int = 300):
        """實盤運行"""
        logger.info("🟢 AI 量化實盤模式啟動")
        df = self.load_data(limit=2000)
        df = self.prepare_data(df)
        self.retrain_if_needed(df)

        last_signal = 0
        while True:
            try:
                # 更新最新數據
                new_ohlcv = self.exchange.fetch_ohlcv(self.symbol, self.tf, limit=2)
                if new_ohlcv[-1][0] != df.index[-1].timestamp() // 1000:
                    new_row = pd.DataFrame([new_ohlcv[-1]], columns=["timestamp", "open", "high", "low", "close", "volume"])
                    new_row["timestamp"] = pd.to_datetime(new_row["timestamp"], unit="ms")
                    new_row.set_index("timestamp", inplace=True)
                    df = pd.concat([df, new_row])
                    df = self.prepare_data(df)

                # 每日重新訓練
                self.retrain_if_needed(df)

                # 生成信號
                signal, conf, votes = self.generate_signal(df)
                price = df["close"].iloc[-1]

                if signal != 0 and signal != last_signal:
                    direction = "多頭" if signal == 1 else "空頭"
                    logger.info(f"🔔 AI 信號：{direction} | 價格={price:.2f} | 置信度={conf*100:.1f}% | 投票={votes}")

                    # 發送 Telegram 通知
                    msg = (f"🤖 <b>AI 量化信號</b>\n"
                           f"品種：{self.symbol}\n"
                           f"方向：{'📈 多頭' if signal == 1 else '📉 空頭'}\n"
                           f"價格：${price:.2f}\n"
                           f"置信度：{conf*100:.1f}%\n"
                           f"投票數：{votes}/4")
                    self.send_telegram(msg)

                    # 下單
                    if signal == 1 and self.position == 0:
                        self._open_position("long", price)
                    elif signal == -1 and self.position == 1:
                        self._close_position(price)

                    last_signal = signal

                logger.info(f"監控中... 價格={price:.2f}, ML置信度={conf*100:.1f}%, 投票={votes}")

            except Exception as e:
                logger.error(f"輪詢錯誤：{e}")

            time.sleep(poll_seconds)

    def _open_position(self, side: str, price: float):
        """開倉"""
        try:
            balance = self.exchange.fetch_balance()
            usdt = balance["USDT"]["free"]
            amount = (usdt * self.config.max_position_pct) / price

            order = self.exchange.create_market_order(
                self.symbol, "buy" if side == "long" else "sell", amount)
            self.position = 1 if side == "long" else -1
            self.entry_price = price
            logger.info(f"✅ 開倉：{side} @ {price:.2f}, 數量={amount:.6f}")
        except Exception as e:
            logger.error(f"❌ 開倉失敗：{e}")

    def _close_position(self, price: float):
        """平倉"""
        try:
            if self.position == 0:
                return
            balance = self.exchange.fetch_balance()
            amount = balance[self.symbol.split("/")[0]]["free"]

            order = self.exchange.create_market_order(
                self.symbol, "sell" if self.position == 1 else "buy", amount)
            pnl = (price - self.entry_price) * amount if self.position == 1 else (self.entry_price - price) * amount
            logger.info(f"✅ 平倉 @ {price:.2f}, PnL={pnl:.2f} USDT")
            self.position = 0
        except Exception as e:
            logger.error(f"❌ 平倉失敗：{e}")


# ═══════════════════════════════════════════════════════════════════
# 主程序
# ═══════════════════════════════════════════════════════════════════

def main():
    if not HAS_ML:
        print("請先安裝依賴：pip install ccxt pandas numpy scikit-learn joblib")
        return

    import os

    # 配置
    exchange = "hyperliquid"
    config = AIQuantConfig()  # 使用默認參數

    strategy = AIQuantStrategy(exchange, config)

    # 回測
    print("\n" + "="*60)
    print("📊 AI 量化全能包 - 歷史回測")
    print("="*60)
    df = strategy.load_data(limit=3000)
    result = strategy.run_backtest(df)

    print(f"\n回測結果：")
    print(f"  總交易次數：{result['total_trades']}")
    print(f"  盈利次數：{result['win_trades']}")
    print(f"  勝率：{result['win_rate']*100:.1f}%")
    print(f"  總盈虧：{result['total_pnl']:.2f} USDT")
    print(f"  最終資金：{result['final_equity']:.2f} USDT")
    print(f"  最大回撤：{result['max_drawdown']*100:.2f}%")

    # 實盤（註釋掉則不運行）
    # strategy.live_run(poll_seconds=300)


if __name__ == "__main__":
    main()
