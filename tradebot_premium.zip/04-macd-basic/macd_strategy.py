#!/usr/bin/env python3
"""
MACD Basic Strategy - Python Implementation
MACD 基础策略

作者: TradeBot
版本: 1.0
"""

import json
import time
import logging
from datetime import datetime
from typing import List, Dict

try:
    import requests
except ImportError:
    print("请先安装 requests: pip install requests")
    exit(1)

# ============== 配置区域 ==============
with open("config.json", "r", encoding="utf-8") as f:
    config = json.load(f)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('trading_log.txt', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

BINANCE_API_BASE = "https://api.binance.com/api/v3"

# ============== 工具函数 ==============

def get_klines(symbol: str, interval: str = "4h", limit: int = 200) -> List[Dict]:
    """获取 K 线数据"""
    url = f"{BINANCE_API_BASE}/klines"
    params = {"symbol": symbol, "interval": interval, "limit": limit}
    
    try:
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        klines = []
        for k in data:
            klines.append({
                "open": float(k[1]),
                "high": float(k[2]),
                "low": float(k[3]),
                "close": float(k[4]),
                "volume": float(k[5])
            })
        return klines
    except Exception as e:
        logger.error(f"获取 {symbol} K线数据失败: {e}")
        return []

def calculate_ema(prices: List[float], period: int) -> float:
    """计算 EMA"""
    if len(prices) < period:
        return 0.0
    
    multiplier = 2 / (period + 1)
    ema = sum(prices[:period]) / period
    
    for price in prices[period:]:
        ema = (price - ema) * multiplier + ema
    
    return ema

def calculate_macd(prices: List[float], fast: int = 12, slow: int = 26, 
                   signal: int = 9) -> Dict:
    """计算 MACD"""
    if len(prices) < slow + signal:
        return {"macd": 0, "signal": 0, "histogram": 0}
    
    # 计算 EMA
    ema_fast = calculate_ema(prices, fast)
    ema_slow = calculate_ema(prices, slow)
    
    macd_line = ema_fast - ema_slow
    
    # 计算信号线（简化版，使用历史 MACD 的 EMA）
    macd_values = []
    for i in range(slow, len(prices)):
        ef = calculate_ema(prices[:i], fast)
        es = calculate_ema(prices[:i], slow)
        macd_values.append(ef - es)
    
    if len(macd_values) >= signal:
        signal_line = calculate_ema(macd_values, signal)
    else:
        signal_line = macd_line
    
    histogram = macd_line - signal_line
    
    return {
        "macd": macd_line,
        "signal": signal_line,
        "histogram": histogram
    }

def get_macd_signal(symbol: str, fast: int = 12, slow: int = 26, 
                    signal: int = 9) -> Dict:
    """分析 MACD 信号"""
    klines = get_klines(symbol, interval="4h", limit=200)
    
    if len(klines) < slow + signal + 2:
        return {"signal": "N/A", "status": "数据不足"}
    
    close_prices = [k["close"] for k in klines]
    
    # 计算当前 MACD
    current = calculate_macd(close_prices, fast, slow, signal)
    
    # 计算前一根 MACD
    prev = calculate_macd(close_prices[:-1], fast, slow, signal)
    
    current_price = close_prices[-1]
    
    # 判断信号
    if prev["macd"] <= prev["signal"] and current["macd"] > current["signal"]:
        signal_type = "GOLDEN_CROSS"  # 金叉
    elif prev["macd"] >= prev["signal"] and current["macd"] < current["signal"]:
        signal_type = "DEATH_CROSS"   # 死叉
    elif current["histogram"] > 0:
        signal_type = "BULLISH"
    else:
        signal_type = "BEARISH"
    
    return {
        "symbol": symbol,
        "price": current_price,
        "macd": current["macd"],
        "signal": current["signal"],
        "histogram": current["histogram"],
        "signal_type": signal_type,
        "status": "多头" if current["histogram"] > 0 else "空头"
    }

def get_recommendation(signal: str, price: float, 
                       stop_pct: float, profit_pct: float) -> str:
    """获取交易建议"""
    if signal == "GOLDEN_CROSS":
        stop = price * (1 - stop_pct/100)
        target = price * (1 + profit_pct/100)
        return f"MACD 金叉！买入 | 止损: ${stop:.2f} | 目标: ${target:.2f}"
    elif signal == "DEATH_CROSS":
        return "MACD 死叉！卖出/平仓"
    elif signal == "BULLISH":
        return "MACD 多头，建议持有"
    else:
        return "MACD 空头，建议观望"

# ============== 主程序 ==============

def main():
    """主函数"""
    
    logger.info("=" * 50)
    logger.info("MACD 基础策略启动")
    logger.info("=" * 50)
    
    symbols = config.get("parameters", {}).get("symbols", ["BTCUSDT"])
    fast = config.get("parameters", {}).get("fast_length", 12)
    slow = config.get("parameters", {}).get("slow_length", 26)
    sig = config.get("parameters", {}).get("signal_length", 9)
    
    logger.info(f"监控交易对: {symbols}")
    logger.info(f"MACD 参数: Fast={fast}, Slow={slow}, Signal={sig}")
    logger.info("-" * 50)
    
    while True:
        for symbol in symbols:
            try:
                result = get_macd_signal(symbol, fast, slow, sig)
                
                if result["signal_type"] != "N/A":
                    icon = "🟢" if "GOLDEN" in result["signal_type"] else \
                           "🔴" if "DEATH" in result["signal_type"] else "⚪"
                    
                    logger.info(
                        f"{icon} {symbol}: ${result['price']:.2f} | "
                        f"MACD: {result['macd']:.4f} | Signal: {result['signal']:.4f} | "
                        f"Histogram: {result['histogram']:.4f} | {result['status']}"
                    )
                    
                    if result["signal_type"] in ["GOLDEN_CROSS", "DEATH_CROSS"]:
                        logger.info(
                            f"   💡 {get_recommendation(result['signal_type'], result['price'], 2.5, 5.0)}"
                        )
                
                time.sleep(0.5)
                
            except Exception as e:
                logger.error(f"处理 {symbol} 时出错: {e}")
        
        logger.info("-" * 50)
        logger.info(f"扫描完成，下次扫描在 60 秒后... ({datetime.now().strftime('%H:%M:%S')})")
        time.sleep(60)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        logger.info("策略已停止")
    except Exception as e:
        logger.error(f"程序异常退出: {e}")