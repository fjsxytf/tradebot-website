"""
套餐 11：超級趨勢策略 (Supertrend Strategy)
交易所：Hyperliquid / Binance / OKX
"""

import json
import time
import logging
from datetime import datetime
from typing import Optional

# === 核心依賴 ===
# pip install ccxt pandas numpy

try:
    import ccxt
    import pandas as pd
    import numpy as np
    HAS_DEPS = True
except ImportError:
    HAS_DEPS = False
    print("⚠️  缺少依賴，請運行：pip install ccxt pandas numpy")

# === 日誌配置 ===
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("supertrend.log", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("SupertrendStrategy")


class SupertrendConfig:
    """超級趨勢策略配置"""

    def __init__(self, config_path: str = None):
        if config_path:
            with open(config_path, "r", encoding="utf-8") as f:
                self._cfg = json.load(f)
        else:
            self._cfg = self._default_config()

        self.symbol      = self._cfg.get("symbol", "BTC/USDT")
        self.timeframe  = self._cfg.get("timeframe", "1h")
        self.atr_period = self._cfg["parameters"]["atr_period"]
        self.atr_mult   = self._cfg["parameters"]["atr_multiplier"]
        self.confirm_bars = self._cfg["parameters"]["confirmation_bars"]
        self.volume_filter = self._cfg["parameters"]["volume_filter"]
        self.volume_threshold = self._cfg["parameters"]["volume_threshold"]
        self.sl_pct     = self._cfg["parameters"]["stop_loss_pct"]
        self.tp_pct    = self._cfg["parameters"]["take_profit_pct"]

    @staticmethod
    def _default_config():
        return {
            "symbol": "BTC/USDT",
            "timeframe": "1h",
            "parameters": {
                "atr_period": 10,
                "atr_multiplier": 3.0,
                "confirmation_bars": 1,
                "volume_filter": True,
                "volume_threshold": 1.5,
                "stop_loss_pct": 2.0,
                "take_profit_pct": 6.0
            }
        }


class Supertrend:
    """超級趨勢指標計算"""

    @staticmethod
    def calculate(df: pd.DataFrame, atr_period: int, atr_mult: float) -> pd.DataFrame:
        """
        計算超級趨勢指標
        返回增加 'st'（超級趨勢值）、'st_dir'（方向）、'st_signal'（買/賣信號）列的 DataFrame
        """
        high = df["high"]
        low  = df["low"]
        close = df["close"]

        # === ATR ===
        tr = pd.concat([
            high - low,
            (high - close.shift(1)).abs(),
            (low  - close.shift(1)).abs()
        ], axis=1).max(axis=1)
        atr = tr.rolling(window=atr_period).mean()

        # === 上軌 / 下軌 ===
        hl2 = (high + low) / 2
        upper_band = hl2 + atr_mult * atr
        lower_band = hl2 - atr_mult * atr

        # === 趨勢方向 (1=多頭, -1=空頭) ===
        st_dir = pd.Series(0.0, index=df.index)
        st_value = pd.Series(0.0, index=df.index)

        direction = 1  # 默認多頭
        st_val = lower_band.iloc[0]

        for i in range(len(df)):
            if direction == 1:
                st_val = lower_band.iloc[i]
                if close.iloc[i] < upper_band.iloc[i]:
                    direction = -1
                    st_val = upper_band.iloc[i]
            else:
                st_val = upper_band.iloc[i]
                if close.iloc[i] > lower_band.iloc[i]:
                    direction = 1
                    st_val = lower_band.iloc[i]

            st_dir.iloc[i] = direction
            st_value.iloc[i] = st_val

        df["st"]       = st_value
        df["st_dir"]   = st_dir

        # === 信號 ===
        df["st_signal"] = 0
        df.loc[df["st_dir"] == 1, "st_signal"] = 1
        df.loc[df["st_dir"] == -1, "st_signal"] = -1

        return df


class SupertrendStrategy:
    """超級趨勢交易策略"""

    def __init__(self, exchange_name: str, config: SupertrendConfig, api_key: str = None, api_secret: str = None):
        if not HAS_DEPS:
            raise RuntimeError("缺少依賴包")

        self.config   = config
        self.symbol   = config.symbol
        self.tf       = config.timeframe

        # === 初始化交易所 ===
        if exchange_name == "hyperliquid":
            self.exchange = ccxt.hyperliquid({
                "enableRateLimit": True,
                "options": {"defaultType": "swap"}}
            )
        elif exchange_name == "binance":
            self.exchange = ccxt.binance({"enableRateLimit": True})
        elif exchange_name == "okx":
            self.exchange = ccxt.okx({"enableRateLimit": True})
        else:
            raise ValueError(f"不支持的交易所：{exchange_name}")

        if api_key and api_secret:
            self.exchange.apiKey = api_key
            self.exchange.secret = api_secret

        self.position   = 0       # 持倉方向：1=多, -1=空, 0=無
        self.entry_price = 0.0
        self.confirm_counter = 0

        logger.info(f"策略初始化：交易所={exchange_name}, 品種={self.symbol}, 周期={self.tf}")

    def load_data(self, limit: int = 200) -> pd.DataFrame:
        """從交易所加載 K 線數據"""
        logger.info(f"正在獲取 K 線數據 (limit={limit})...")
        ohlcv = self.exchange.fetch_ohlcv(self.symbol, self.tf, limit=limit)
        df = pd.DataFrame(ohlcv, columns=["timestamp", "open", "high", "low", "close", "volume"])
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")
        df.set_index("timestamp", inplace=True)
        return df

    def check_volume(self, df: pd.DataFrame, last_n: int = 20) -> bool:
        """成交量過濾"""
        if not self.config.volume_filter:
            return True
        recent_vol = df["volume"].iloc[-last_n:].mean()
        return df["volume"].iloc[-1] >= recent_vol * self.config.volume_threshold

    def generate_signal(self, df: pd.DataFrame) -> int:
        """
        生成交易信號
        返回：1=買入, -1=賣出, 0=無信號
        """
        last_row  = df.iloc[-1]
        prev_row  = df.iloc[-2]
        direction = last_row["st_dir"]

        # === 多頭信號：趨勢由空轉多 ===
        if direction == 1 and prev_row["st_dir"] == -1:
            if self.check_volume(df):
                logger.info(f"🔔 多頭信號！價格={last_row['close']:.4f}, ST={last_row['st']:.4f}")
                return 1

        # === 空頭信號：趨勢由多轉空 ===
        elif direction == -1 and prev_row["st_dir"] == 1:
            if self.check_volume(df):
                logger.info(f"🔔 空頭信號！價格={last_row['close']:.4f}, ST={last_row['st']:.4f}")
                return -1

        return 0

    def run_backtest(self, df: pd.DataFrame) -> dict:
        """歷史回測"""
        df = Supertrend.calculate(df, self.config.atr_period, self.config.atr_mult)

        capital   = 10000.0   # 初始資金 10000 USDT
        position  = 0.0
        entry     = 0.0
        trades    = []
        equity    = []

        for i in range(50, len(df)):
            row = df.iloc[i]
            signal = self._signal_at(df, i)

            if signal == 1 and position == 0:
                entry    = row["close"]
                position = capital / entry
                logger.info(f"[回測] 買入 @ {entry:.4f}, 數量={position:.6f}")

            elif signal == -1 and position > 0:
                exit_price = row["close"]
                pnl = (exit_price - entry) * position
                capital += pnl
                trades.append({"entry": entry, "exit": exit_price, "pnl": pnl, "dir": "long"})
                logger.info(f"[回測] 賣出 @ {exit_price:.4f}, PnL={pnl:.2f} USDT")
                position = 0.0

            cur_val = capital + position * row["close"] if position > 0 else capital
            equity.append(cur_val)

        win_trades  = [t for t in trades if t["pnl"] > 0]
        loss_trades = [t for t in trades if t["pnl"] <= 0]
        total_pnl   = sum(t["pnl"] for t in trades)

        return {
            "total_trades":   len(trades),
            "win_trades":     len(win_trades),
            "loss_trades":    len(loss_trades),
            "win_rate":       len(win_trades) / len(trades) if trades else 0,
            "total_pnl":      total_pnl,
            "final_equity":   equity[-1] if equity else capital,
            "max_drawdown":   self._max_drawdown(equity),
            "equity_curve":   equity,
        }

    def _signal_at(self, df: pd.DataFrame, i: int) -> int:
        if i < 2:
            return 0
        row  = df.iloc[i]
        prev = df.iloc[i - 1]
        if row["st_dir"] == 1 and prev["st_dir"] == -1:
            return 1
        elif row["st_dir"] == -1 and prev["st_dir"] == 1:
            return -1
        return 0

    @staticmethod
    def _max_drawdown(equity: list) -> float:
        peak = equity[0]
        max_dd = 0.0
        for v in equity:
            if v > peak:
                peak = v
            dd = (peak - v) / peak
            if dd > max_dd:
                max_dd = dd
        return max_dd

    def place_order(self, side: str, amount: float = None) -> dict:
        """下單"""
        try:
            if amount is None:
                balance = self.exchange.fetch_balance()
                usdt    = balance["USDT"]["free"]
                price   = self.exchange.fetch_ticker(self.symbol)["last"]
                amount  = (usdt * 0.95) / price  # 使用 95% 資金

            order = self.exchange.create_market_order(self.symbol,
                         "buy" if side == "long" else "sell", amount)
            logger.info(f"✅ {'多頭' if side == 'long' else '空頭'}訂單成交: {json.dumps(order, ensure_ascii=False)}")
            return order
        except Exception as e:
            logger.error(f"❌ 下單失敗：{e}")
            return {}

    def live_run(self, poll_seconds: int = 60):
        """實盤運行（每 poll_seconds 檢查一次）"""
        logger.info("🟢 實盤模式啟動，按 Ctrl+C 停止")
        df = self.load_data(limit=300)
        df = Supertrend.calculate(df, self.config.atr_period, self.config.atr_mult)

        last_signal = 0
        while True:
            try:
                # 更新最新 K 線
                new_ohlcv = self.exchange.fetch_ohlcv(self.symbol, self.tf, limit=2)
                if new_ohlcv[-1][0] != df.index[-1]:
                    new_row = pd.DataFrame([new_ohlcv[-1]], columns=["timestamp", "open", "high", "low", "close", "volume"])
                    new_row["timestamp"] = pd.to_datetime(new_row["timestamp"], unit="ms")
                    new_row.set_index("timestamp", inplace=True)
                    df = pd.concat([df, new_row])

                df = Supertrend.calculate(df, self.config.atr_period, self.config.atr_mult)
                signal = self.generate_signal(df)

                if signal == 1 and last_signal != 1:
                    self.place_order("long")
                    last_signal = 1
                elif signal == -1 and last_signal != -1:
                    self.place_order("short")
                    last_signal = -1

                logger.info(f"監控中... 價格={df['close'].iloc[-1]:.4f}, 趨勢={'多' if df['st_dir'].iloc[-1]==1 else '空'}")

            except Exception as e:
                logger.error(f"輪詢錯誤：{e}")

            time.sleep(poll_seconds)


def main():
    # === 配置 ===
    exchange = "hyperliquid"  # 或 "binance" / "okx"
    config   = SupertrendConfig()  # 使用默認參數

    strategy = SupertrendStrategy(exchange, config)

    # === 回測 ===
    print("\n" + "="*50)
    print("📊 開始歷史回測")
    print("="*50)
    df = strategy.load_data(limit=1000)
    result = strategy.run_backtest(df)

    print(f"\n回測結果：")
    print(f"  總交易次數：{result['total_trades']}")
    print(f"  盈利次數：{result['win_trades']}")
    print(f"  虧損次數：{result['loss_trades']}")
    print(f"  勝率：{result['win_rate']*100:.1f}%")
    print(f"  總盈虧：{result['total_pnl']:.2f} USDT")
    print(f"  最終資金：{result['final_equity']:.2f} USDT")
    print(f"  最大回撤：{result['max_drawdown']*100:.2f}%")

    # === 實盤 ===
    # strategy.live_run(poll_seconds=60)


if __name__ == "__main__":
    main()
