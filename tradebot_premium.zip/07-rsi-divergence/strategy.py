"""
RSI 背离专精策略 - Python 实盘版本
策略编号: 07
价格: $4.99 (进阶系列)
"""

import asyncio
import json
import logging
from dataclasses import dataclass
from typing import Optional, List, Tuple
import pandas as pd
import numpy as np

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class StrategyConfig:
    rsi_period: int = 14
    overbought: int = 70
    oversold: int = 30
    lookback: int = 20
    risk_per_trade: float = 0.02
    exchanges: List[str] = None
    
    def __post_init__(self):
        if self.exchanges is None:
            self.exchanges = ["hyperliquid"]


class RSIDivergence:
    """
    RSI 背离策略
    
    核心逻辑:
    1. 检测价格的局部高点/低点
    2. 检测同期 RSI 的高点/低点
    3. 比较前后两个极值点，识别背离
    """
    
    def __init__(self, config: StrategyConfig):
        self.config = config
        self.position = 0
        self.data = pd.DataFrame()
        
    def calculate_rsi(self, prices: pd.Series, period: int = 14) -> pd.Series:
        """计算 RSI"""
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        return rsi
    
    def find_pivots(self, series: pd.Series, left: int = 5, right: int = 5) -> pd.Series:
        """查找枢轴点（局部极值）"""
        pivots = pd.Series(index=series.index, dtype=float)
        
        for i in range(left, len(series) - right):
            window = series.iloc[i-left:i+right+1]
            if series.iloc[i] == window.max():
                pivots.iloc[i] = 1  # 高点
            elif series.iloc[i] == window.min():
                pivots.iloc[i] = -1  # 低点
        
        return pivots
    
    def detect_divergence(self) -> Tuple[bool, bool]:
        """
        检测背离
        
        Returns:
            (bullish_divergence, bearish_divergence)
        """
        if len(self.data) < self.config.lookback + 10:
            return False, False
        
        # 计算 RSI
        self.data['rsi'] = self.calculate_rsi(self.data['close'], self.config.rsi_period)
        
        # 查找价格枢轴点
        price_pivots = self.find_pivots(self.data['close'])
        rsi_pivots = self.find_pivots(self.data['rsi'])
        
        # 获取最近的高点/低点
        recent_data = self.data.tail(self.config.lookback)
        
        # 查找两个最近的低点（看涨背离）
        low_points = price_pivots[price_pivots == -1].tail(2)
        rsi_low_points = rsi_pivots[rsi_pivots == -1].tail(2)
        
        bullish_div = False
        if len(low_points) >= 2 and len(rsi_low_points) >= 2:
            price_lower_low = self.data['close'].iloc[low_points.index[-1]] < self.data['close'].iloc[low_points.index[-2]]
            rsi_higher_low = self.data['rsi'].iloc[rsi_low_points.index[-1]] > self.data['rsi'].iloc[rsi_low_points.index[-2]]
            rsi_recent_low = self.data['rsi'].iloc[rsi_low_points.index[-1]] < 40
            bullish_div = price_lower_low and rsi_higher_low and rsi_recent_low
        
        # 查找两个最近的高点（看跌背离）
        high_points = price_pivots[price_pivots == 1].tail(2)
        rsi_high_points = rsi_pivots[rsi_pivots == 1].tail(2)
        
        bearish_div = False
        if len(high_points) >= 2 and len(rsi_high_points) >= 2:
            price_higher_high = self.data['close'].iloc[high_points.index[-1]] > self.data['close'].iloc[high_points.index[-2]]
            rsi_lower_high = self.data['rsi'].iloc[rsi_high_points.index[-1]] < self.data['rsi'].iloc[rsi_high_points.index[-2]]
            rsi_recent_high = self.data['rsi'].iloc[rsi_high_points.index[-1]] > 60
            bearish_div = price_higher_high and rsi_lower_high and rsi_recent_high
        
        return bullish_div, bearish_div
    
    def generate_signal(self) -> Optional[str]:
        """生成交易信号"""
        if len(self.data) < 30:
            return None
        
        bullish_div, bearish_div = self.detect_divergence()
        current_rsi = self.calculate_rsi(self.data['close']).iloc[-1]
        
        if self.position == 0:
            if bullish_div:
                logger.info(f"🟢 检测到看涨背离 | RSI: {current_rsi:.1f}")
                return "long"
            elif bearish_div:
                logger.info(f"🔴 检测到看跌背离 | RSI: {current_rsi:.1f}")
                return "short"
        
        elif self.position == 1 and current_rsi > self.config.overbought - 5:
            logger.info(f"📕 RSI接近超买，平多仓 | RSI: {current_rsi:.1f}")
            return "close_long"
        
        elif self.position == -1 and current_rsi < self.config.oversold + 5:
            logger.info(f"📗 RSI接近超卖，平空仓 | RSI: {current_rsi:.1f}")
            return "close_short"
        
        return None
    
    async def run(self):
        """主运行循环"""
        logger.info("=" * 50)
        logger.info("RSI 背离专精策略启动")
        logger.info(f"配置: RSI({self.config.rsi_period}), 超买{self.config.overbought}/超卖{self.config.oversold}")
        logger.info("=" * 50)
        
        while True:
            try:
                signal = self.generate_signal()
                if signal:
                    current_price = self.data['close'].iloc[-1] if len(self.data) > 0 else 0
                    if signal == "long":
                        self.position = 1
                        logger.info(f"🚀 开多仓 @ {current_price:.2f}")
                    elif signal == "short":
                        self.position = -1
                        logger.info(f"🚀 开空仓 @ {current_price:.2f}")
                    elif signal in ["close_long", "close_short"]:
                        self.position = 0
                        logger.info(f"🔒 平仓 @ {current_price:.2f}")
                
                await asyncio.sleep(60)
                
            except Exception as e:
                logger.error(f"策略运行错误: {e}")
                await asyncio.sleep(60)


def load_config(path: str) -> StrategyConfig:
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    return StrategyConfig(
        rsi_period=data.get("indicators", {}).get("rsi", {}).get("period", 14),
        overbought=data.get("indicators", {}).get("rsi", {}).get("overbought", 70),
        oversold=data.get("indicators", {}).get("rsi", {}).get("oversold", 30),
        risk_per_trade=data.get("risk_management", {}).get("risk_per_trade", 0.02),
        exchanges=data.get("exchanges", ["hyperliquid"])
    )


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config.json")
    args = parser.parse_args()
    
    config = load_config(args.config)
    strategy = RSIDivergence(config)
    asyncio.run(strategy.run())
