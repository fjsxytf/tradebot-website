"""
套餐 13：分形鱷魚策略 (Fractal + Alligator)
交易所：Hyperliquid / Binance / OKX
"""

import json
import time
import logging
from typing import Optional

try:
    import ccxt
    import pandas as pd
    import numpy as np
    HAS_DEPS = True
except ImportError:
    HAS_DEPS = False
    print("⚠️ 缺少依賴，請運行：pip install ccxt pandas numpy")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("fractal_alligator.log", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("FractalAlligator")


class FractalAlligatorConfig:
    def __init__(self, config_path: str = None):
        if config_path:
            with open(config_path, "r", encoding="utf-8") as f:
                cfg = json.load(f)
        else:
            cfg = self._default()
        self.symbol       = cfg.get("symbol", "BTC/USDT:USDT")
        self.timeframe    = cfg.get("timeframe", "1h")
        p = cfg["parameters"]
        self.jaw_period   = p["alligator_jaw_period"]
        self.teeth_period = p["alligator_teeth_period"]
        self.lips_period  = p["alligator_lips_period"]
        self.fractal_bars = p["fractal_confirm"]
        self.await_close  = p.get("await_closing_bars", True)
        self.sl_pct       = p["stop_loss_pct"]
        self.tp_pct       = p["take_profit_pct"]

    @staticmethod
    def _default():
        return {
            "symbol": "BTC/USDT:USDT",
            "timeframe": "1h",
            "parameters": {
                "alligator_jaw_period": 13,
                "alligator_teeth_period": 8,
                "alligator_lips_period": 5,
                "fractal_confirm": 2,
                "await_closing_bars": True,
                "stop_loss_pct": 3.0,
                "take_profit_pct": 9.0
            }
        }


class FractalAlligator:
    """分形 + 鱷魚線指標"""

    @staticmethod
    def calculate(df: pd.DataFrame, jaw_p: int, teeth_p: int, lips_p: int,
                  fractal_bars: int) -> pd.DataFrame:
        # === 鱷魚線 ===
        df["jaw"]   = df["close"].rolling(jaw_p).mean()   # 顎線
        df["teeth"] = df["close"].rolling(teeth_p).mean() # 齒線
        df["lips"]  = df["close"].rolling(lips_p).mean()  # 唇線

        # === 鱷魚狀態 ===
        df["alligator_awake"] = (df["jaw"] < df["teeth"]) & (df["teeth"] < df["lips"])

        # === 上分形 ===
        def is_upper_fractal(i):
            if i < fractal_bars:
                return False
            sig_high = df["high"].iloc[i]
            for offset in range(1, fractal_bars + 1):
                if offset != fractal_bars and df["high"].iloc[i - offset] >= sig_high:
                    return False
            return True

        # === 下分形 ===
        def is_lower_fractal(i):
            if i < fractal_bars:
                return False
            sig_low = df["low"].iloc[i]
            for offset in range(1, fractal_bars + 1):
                if offset != fractal_bars and df["low"].iloc[i - offset] <= sig_low:
                    return False
            return True

        df["upper_fractal"] = False
        df["lower_fractal"] = False
        for i in range(fractal_bars, len(df)):
            df.iloc[i, df.columns.get_loc("upper_fractal")] = is_upper_fractal(i)
            df.iloc[i, df.columns.get_loc("lower_fractal")] = is_lower_fractal(i)

        return df

    @staticmethod
    def generate_signal(df: pd.DataFrame, await_close: bool) -> int:
        if len(df) < 10:
            return 0
        last = df.iloc[-1]
        prev = df.iloc[-2]

        bull = last["upper_fractal"] and last["alligator_awake"]
        bear = last["lower_fractal"] and not last["alligator_awake"]

        if await_close:
            bull = bull and last["close"] > last["open"]
            bear = bear and last["close"] < last["open"]

        if bull:
            logger.info(f"🔔 分形鱷魚多頭信號！價格={last['close']:.4f}")
            return 1
        elif bear:
            logger.info(f"🔔 分形鱷魚空頭信號！價格={last['close']:.4f}")
            return -1
        return 0


class FractalAlligatorStrategy:
    def __init__(self, exchange_name: str, config: FractalAlligatorConfig):
        if not HAS_DEPS:
            raise RuntimeError("缺少依賴包")
        self.config = config
        self.exchange = self._init_exchange(exchange_name)
        self.position = 0
        logger.info(f"分形鱷魚策略初始化：{exchange_name}, {config.symbol}")

    def _init_exchange(self, name: str):
        if name == "hyperliquid":
            return ccxt.hyperliquid({"enableRateLimit": True})
        elif name == "binance":
            return ccxt.binance({"enableRateLimit": True})
        elif name == "okx":
            return ccxt.okx({"enableRateLimit": True})
        raise ValueError(f"不支持的交易所：{name}")

    def load_data(self, limit: int = 300) -> pd.DataFrame:
        logger.info(f"正在獲取 K 線數據 (limit={limit})...")
        ohlcv = self.exchange.fetch_ohlcv(self.config.symbol, self.config.timeframe, limit=limit)
        df = pd.DataFrame(ohlcv, columns=["timestamp", "open", "high", "low", "close", "volume"])
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")
        df.set_index("timestamp", inplace=True)
        return df

    def run_backtest(self, df: pd.DataFrame) -> dict:
        cfg = self.config
        df = FractalAlligator.calculate(df, cfg.jaw_period, cfg.teeth_period,
                                       cfg.lips_period, cfg.fractal_bars)
        capital = 10000.0
        position = 0.0
        entry = 0.0
        trades = []
        equity = []

        for i in range(cfg.jaw_period + cfg.fractal_bars, len(df)):
            sig = FractalAlligator.generate_signal(df.iloc[:i+1], cfg.await_close)
            row = df.iloc[i]

            if sig == 1 and position == 0:
                entry = row["close"]
                position = capital / entry
                logger.info(f"[回測] 多頭 @ {entry:.4f}")
            elif sig == -1 and position > 0:
                exit_p = row["close"]
                pnl = (exit_p - entry) * position
                capital += pnl
                trades.append({"entry": entry, "exit": exit_p, "pnl": pnl})
                logger.info(f"[回測] 平倉 @ {exit_p:.4f}, PnL={pnl:.2f}")
                position = 0.0

            cur = capital + position * row["close"] if position > 0 else capital
            equity.append(cur)

        wins = [t for t in trades if t["pnl"] > 0]
        return {
            "total_trades": len(trades),
            "win_trades": len(wins),
            "win_rate": len(wins) / len(trades) if trades else 0,
            "total_pnl": sum(t["pnl"] for t in trades),
            "final_equity": equity[-1] if equity else capital,
        }

    def live_run(self, poll_seconds: int = 120):
        logger.info("🟢 分形鱷魚實盤模式啟動")
        cfg = self.config
        df = self.load_data(500)
        df = FractalAlligator.calculate(df, cfg.jaw_period, cfg.teeth_period,
                                       cfg.lips_period, cfg.fractal_bars)
        last_sig = 0
        while True:
            try:
                ohlcv = self.exchange.fetch_ohlcv(cfg.symbol, cfg.timeframe, limit=2)
                if ohlcv[-1][0] != df.index[-1]:
                    new_row = pd.DataFrame([ohlcv[-1]],
                        columns=["timestamp","open","high","low","close","volume"])
                    new_row["timestamp"] = pd.to_datetime(new_row["timestamp"], unit="ms")
                    new_row.set_index("timestamp", inplace=True)
                    df = pd.concat([df, new_row])

                df = FractalAlligator.calculate(df, cfg.jaw_period, cfg.teeth_period,
                                               cfg.lips_period, cfg.fractal_bars)
                sig = FractalAlligator.generate_signal(df, cfg.await_close)

                if sig == 1 and last_sig != 1:
                    logger.info(f"🔔 實盤多頭信號！")
                    last_sig = 1
                elif sig == -1 and last_sig != -1:
                    logger.info(f"🔔 實盤空頭信號！")
                    last_sig = -1
            except Exception as e:
                logger.error(f"輪詢錯誤：{e}")
            time.sleep(poll_seconds)


def main():
    config = FractalAlligatorConfig()
    strat  = FractalAlligatorStrategy("hyperliquid", config)
    df = strat.load_data(1000)
    result = strat.run_backtest(df)
    print(f"分形鱷魚回測：總交易={result['total_trades']} | 勝率={result['win_rate']*100:.1f}% | 盈虧={result['total_pnl']:.2f} USDT")


if __name__ == "__main__":
    main()
