#!/usr/bin/env python3
"""
RSI Extreme Trading Strategy - Python Implementation
RSI 超买超卖交易策略

作者: TradeBot
版本: 1.0
"""

import json
import time
import logging
from datetime import datetime
from typing import List, Dict

try:
    import requests
except ImportError:
    print("请先安装 requests: pip install requests")
    exit(1)

# ============== 配置区域 ==============
with open("config.json", "r", encoding="utf-8") as f:
    config = json.load(f)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('trading_log.txt', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

BINANCE_API_BASE = "https://api.binance.com/api/v3"

# ============== 工具函数 ==============

def get_klines(symbol: str, interval: str = "4h", limit: int = 100) -> List[Dict]:
    """获取 K 线数据"""
    url = f"{BINANCE_API_BASE}/klines"
    params = {"symbol": symbol, "interval": interval, "limit": limit}
    
    try:
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        klines = []
        for k in data:
            klines.append({
                "open": float(k[1]),
                "high": float(k[2]),
                "low": float(k[3]),
                "close": float(k[4]),
                "volume": float(k[5])
            })
        return klines
    except Exception as e:
        logger.error(f"获取 {symbol} K线数据失败: {e}")
        return []

def calculate_rsi(prices: List[float], period: int = 14) -> float:
    """计算 RSI"""
    if len(prices) < period + 1:
        return 50.0
    
    deltas = [prices[i] - prices[i-1] for i in range(1, len(prices))]
    
    gains = [d if d > 0 else 0 for d in deltas[-period:]]
    losses = [-d if d < 0 else 0 for d in deltas[-period:]]
    
    avg_gain = sum(gains) / period
    avg_loss = sum(losses) / period
    
    if avg_loss == 0:
        return 100.0
    
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    
    return rsi

def get_rsi_signal(symbol: str, period: int = 14, oversold: int = 20, 
                   overbought: int = 80) -> Dict:
    """分析 RSI 信号"""
    klines = get_klines(symbol, interval="4h", limit=100)
    
    if len(klines) < period + 1:
        return {"signal": "N/A", "status": "数据不足"}
    
    close_prices = [k["close"] for k in klines]
    
    # 计算当前 RSI
    current_rsi = calculate_rsi(close_prices, period)
    
    # 计算前一根 RSI
    prev_rsi = calculate_rsi(close_prices[:-1], period)
    
    current_price = close_prices[-1]
    
    # 判断信号
    if prev_rsi <= oversold and current_rsi > oversold:
        signal = "BUY"  # RSI 从超卖区回升
    elif prev_rsi >= overbought and current_rsi < overbought:
        signal = "SELL"  # RSI 从超买区回落
    elif current_rsi < oversold:
        signal = "OVERSOLD"  # 仍在超卖区
    elif current_rsi > overbought:
        signal = "OVERBOUGHT"  # 仍在超买区
    else:
        signal = "NEUTRAL"
    
    # 判断状态
    if current_rsi < 30:
        status = "超卖 📉"
    elif current_rsi > 70:
        status = "超买 📈"
    else:
        status = "中性"
    
    return {
        "symbol": symbol,
        "price": current_price,
        "rsi": current_rsi,
        "signal": signal,
        "status": status,
        "recommendation": get_recommendation(signal, current_price, 
            config.get("parameters", {}).get("stop_loss_pct", 3.0),
            config.get("parameters", {}).get("take_profit_pct", 6.0))
    }

def get_recommendation(signal: str, price: float, stop_pct: float, 
                       profit_pct: float) -> str:
    """获取交易建议"""
    if signal == "BUY":
        stop = price * (1 - stop_pct/100)
        target = price * (1 + profit_pct/100)
        return f"考虑买入 | 止损: ${stop:.2f} | 目标: ${target:.2f}"
    elif signal == "SELL":
        return "考虑卖出/平仓"
    elif signal == "OVERSOLD":
        return "等待 RSI 回升确认"
    elif signal == "OVERBOUGHT":
        return "等待 RSI 回落确认"
    return "观望"

# ============== 主程序 ==============

def main():
    """主函数"""
    
    logger.info("=" * 50)
    logger.info("RSI 超买超卖策略启动")
    logger.info("=" * 50)
    
    symbols = config.get("parameters", {}).get("symbols", ["BTCUSDT"])
    rsi_period = config.get("parameters", {}).get("rsi_period", 14)
    oversold = config.get("parameters", {}).get("oversold", 20)
    overbought = config.get("parameters", {}).get("overbought", 80)
    
    logger.info(f"监控交易对: {symbols}")
    logger.info(f"RSI 周期: {rsi_period} | 超卖: {oversold} | 超买: {overbought}")
    logger.info("-" * 50)
    
    while True:
        for symbol in symbols:
            try:
                result = get_rsi_signal(symbol, rsi_period, oversold, overbought)
                
                if result["signal"] != "N/A":
                    signal_icon = "🟢" if result["signal"] == "BUY" else \
                                  "🔴" if result["signal"] == "SELL" else "⚪"
                    
                    logger.info(
                        f"{signal_icon} {symbol}: ${result['price']:.2f} | "
                        f"RSI: {result['rsi']:.1f} ({result['status']}) | "
                        f"信号: {result['signal']}"
                    )
                    
                    if result["signal"] in ["BUY", "SELL"]:
                        logger.info(f"   💡 {result['recommendation']}")
                
                time.sleep(0.5)
                
            except Exception as e:
                logger.error(f"处理 {symbol} 时出错: {e}")
        
        logger.info("-" * 50)
        logger.info(f"扫描完成，下次扫描在 60 秒后... ({datetime.now().strftime('%H:%M:%S')})")
        time.sleep(60)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        logger.info("策略已停止")
    except Exception as e:
        logger.error(f"程序异常退出: {e}")