"""
自适应布林带策略 - Python 实盘版本
策略编号: 09
价格: $4.99 (进阶系列)
"""

import asyncio
import json
import logging
from dataclasses import dataclass
from typing import Optional, List, Tuple
import pandas as pd
import numpy as np

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class StrategyConfig:
    bb_period: int = 20
    bb_base_mult: float = 2.0
    atr_period: int = 14
    volatility_factor: float = 1.5
    risk_per_trade: float = 0.02
    exchanges: List[str] = None
    
    def __post_init__(self):
        if self.exchanges is None:
            self.exchanges = ["hyperliquid"]


class AdaptiveBollinger:
    """
    自适应布林带策略
    
    核心逻辑:
    1. 根据 ATR 动态调整布林带宽度
    2. 只在趋势方向交易
    3. 带宽从收缩开始扩大时入场
    """
    
    def __init__(self, config: StrategyConfig):
        self.config = config
        self.position = 0
        self.data = pd.DataFrame()
        
    def calculate_atr(self, df: pd.DataFrame, period: int = 14) -> pd.Series:
        """计算 ATR"""
        high_low = df['high'] - df['low']
        high_close = np.abs(df['high'] - df['close'].shift())
        low_close = np.abs(df['low'] - df['close'].shift())
        ranges = pd.concat([high_low, high_close, low_close], axis=1)
        true_range = np.max(ranges, axis=1)
        atr = true_range.rolling(period).mean()
        return atr
    
    def calculate_adaptive_bollinger(self, df: pd.DataFrame) -> Tuple[pd.Series, pd.Series, pd.Series, pd.Series]:
        """
        计算自适应布林带
        
        Returns:
            (middle, upper, lower, adaptive_mult)
        """
        # 中轨
        middle = df['close'].rolling(self.config.bb_period).mean()
        
        # 计算 ATR 自适应倍数
        atr = self.calculate_atr(df, self.config.atr_period)
        atr_sma = atr.rolling(self.config.bb_period).mean()
        volatility_ratio = atr / atr_sma
        adaptive_mult = self.config.bb_base_mult * (1 + (volatility_ratio - 1) * self.config.volatility_factor)
        
        # 标准差
        std = df['close'].rolling(self.config.bb_period).std()
        
        # 上下轨
        upper = middle + adaptive_mult * std
        lower = middle - adaptive_mult * std
        
        return middle, upper, lower, adaptive_mult
    
    def analyze_bandwidth(self, upper: pd.Series, lower: pd.Series, middle: pd.Series) -> Tuple[bool, bool]:
        """
        分析带宽状态
        
        Returns:
            (is_squeeze, is_expanding)
        """
        bandwidth = (upper - lower) / middle * 100
        bandwidth_sma = bandwidth.rolling(20).mean()
        
        is_squeeze = bandwidth.iloc[-1] < bandwidth_sma.iloc[-1] * 0.85
        is_expanding = bandwidth.iloc[-1] > bandwidth.iloc[-2] > bandwidth.iloc[-3]
        
        return is_squeeze, is_expanding
    
    def generate_signal(self) -> Optional[str]:
        """生成交易信号"""
        if len(self.data) < self.config.bb_period + 20:
            return None
        
        middle, upper, lower, _ = self.calculate_adaptive_bollinger(self.data)
        is_squeeze, is_expanding = self.analyze_bandwidth(upper, lower, middle)
        
        current_close = self.data['close'].iloc[-1]
        trend_ema = self.data['close'].ewm(span=50).mean().iloc[-1]
        trend_up = current_close > trend_ema
        trend_down = current_close < trend_ema
        
        if self.position == 0:
            if current_close <= lower.iloc[-1] and trend_up and is_expanding:
                logger.info(f"🟢 自适应下轨做多 | 价格: {current_close:.2f}")
                return "long"
            elif current_close >= upper.iloc[-1] and trend_down and is_expanding:
                logger.info(f"🔴 自适应上轨做空 | 价格: {current_close:.2f}")
                return "short"
        
        elif self.position == 1 and current_close >= middle.iloc[-1]:
            logger.info("📕 价格回归中轨，平多仓")
            return "close_long"
        
        elif self.position == -1 and current_close <= middle.iloc[-1]:
            logger.info("📗 价格回归中轨，平空仓")
            return "close_short"
        
        return None
    
    async def run(self):
        """主运行循环"""
        logger.info("=" * 50)
        logger.info("自适应布林带策略启动")
        logger.info(f"配置: BB周期{self.config.bb_period}, 基础倍数{self.config.bb_base_mult}")
        logger.info("=" * 50)
        
        while True:
            try:
                signal = self.generate_signal()
                if signal:
                    current_price = self.data['close'].iloc[-1] if len(self.data) > 0 else 0
                    if signal == "long":
                        self.position = 1
                        logger.info(f"🚀 开多仓 @ {current_price:.2f}")
                    elif signal == "short":
                        self.position = -1
                        logger.info(f"🚀 开空仓 @ {current_price:.2f}")
                    elif signal in ["close_long", "close_short"]:
                        self.position = 0
                        logger.info(f"🔒 平仓 @ {current_price:.2f}")
                
                await asyncio.sleep(60)
                
            except Exception as e:
                logger.error(f"策略运行错误: {e}")
                await asyncio.sleep(60)


def load_config(path: str) -> StrategyConfig:
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    bb = data.get("indicators", {}).get("bollinger", {})
    return StrategyConfig(
        bb_period=bb.get("period", 20),
        bb_base_mult=bb.get("base_multiplier", 2.0),
        risk_per_trade=data.get("risk_management", {}).get("risk_per_trade", 0.02),
        exchanges=data.get("exchanges", ["hyperliquid"])
    )


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config.json")
    args = parser.parse_args()
    
    config = load_config(args.config)
    strategy = AdaptiveBollinger(config)
    asyncio.run(strategy.run())
