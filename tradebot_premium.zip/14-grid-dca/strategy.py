"""
套餐 14：網格 DCA 大師策略 (Grid DCA Mastery)
交易所：Hyperliquid / Binance / OKX
"""

import json
import time
import logging
from datetime import datetime
from typing import Dict, List, Optional

try:
    import ccxt
    import pandas as pd
    import numpy as np
    HAS_DEPS = True
except ImportError:
    HAS_DEPS = False
    print("⚠️ 缺少依賴，請運行：pip install ccxt pandas numpy")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("grid_dca.log", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("GridDCA")


class GridDCAConfig:
    def __init__(self, config_path: str = None):
        if config_path:
            with open(config_path, "r", encoding="utf-8") as f:
                cfg = json.load(f)
        else:
            cfg = self._default()
        self.symbol          = cfg.get("symbol", "BTC/USDT:USDT")
        self.timeframe       = cfg.get("timeframe", "4h")
        p = cfg["parameters"]
        self.grid_levels     = p["grid_levels"]
        self.grid_spacing    = p["grid_spacing_pct"] / 100.0
        self.dca_per_grid    = p["dca_amount_per_grid"]
        self.base_price      = p.get("base_price", 0.0)
        self.max_position    = p["max_total_position"]
        self.tp_pct          = p["tp_per_grid_pct"] / 100.0
        self.use_vol_filter  = p.get("use_volatility_filter", True)
        self.atr_mult_f      = p.get("atr_multiplier_for_filter", 2.0)

    @staticmethod
    def _default():
        return {
            "symbol": "BTC/USDT:USDT",
            "timeframe": "4h",
            "parameters": {
                "grid_levels": 5,
                "grid_spacing_pct": 3.0,
                "dca_amount_per_grid": 100.0,
                "base_price": 0.0,
                "max_total_position": 5000.0,
                "tp_per_grid_pct": 2.0,
                "use_volatility_filter": True,
                "atr_multiplier_for_filter": 2.0
            }
        }


class GridDCA:
    """網格 DCA 策略"""

    def __init__(self, exchange_name: str, config: GridDCAConfig):
        if not HAS_DEPS:
            raise RuntimeError("缺少依賴包")
        self.config   = config
        self.exchange  = self._init_exchange(exchange_name)
        self.base_price = config.base_price
        self.grid_levels = config.grid_levels
        self.grid_spacing = config.grid_spacing
        self.positions: Dict[int, dict] = {}  # grid_level -> {entry_price, qty, sold}
        self.total_invested = 0.0
        logger.info(f"網格 DCA 策略初始化：{exchange_name}, {config.symbol}")

    def _init_exchange(self, name: str):
        if name == "hyperliquid":
            return ccxt.hyperliquid({"enableRateLimit": True})
        elif name == "binance":
            return ccxt.binance({"enableRateLimit": True})
        elif name == "okx":
            return ccxt.okx({"enableRateLimit": True})
        raise ValueError(f"不支持的交易所：{name}")

    def _get_base_price(self) -> float:
        if self.base_price > 0:
            return self.base_price
        ticker = self.exchange.fetch_ticker(self.config.symbol)
        self.base_price = ticker["last"]
        logger.info(f"自動獲取基準價：{self.base_price:.4f}")
        return self.base_price

    def _calculate_grid_prices(self, base_price: float) -> tuple:
        buy_prices  = [base_price * (1 - self.grid_spacing * i) for i in range(1, self.grid_levels + 1)]
        sell_prices = [base_price * (1 + self.grid_spacing * i) for i in range(1, self.grid_levels + 1)]
        return buy_prices, sell_prices

    def _atr_filter(self) -> bool:
        if not self.config.use_vol_filter:
            return True
        try:
            ohlcv = self.exchange.fetch_ohlcv(self.config.symbol, self.config.timeframe, limit=30)
            df = pd.DataFrame(ohlcv, columns=["timestamp", "open", "high", "low", "close", "volume"])
            tr = pd.concat([
                df["high"] - df["low"],
                (df["high"] - df["close"].shift(1)).abs(),
                (df["low"] - df["close"].shift(1)).abs()
            ], axis=1).max(axis=1)
            atr = tr.mean()
            current_atr = tr.iloc[-1]
            return current_atr >= atr * self.config.atr_mult_f
        except Exception:
            return True

    def _place_dca_buy(self, level: int, buy_price: float):
        """在指定網格買入"""
        qty = self.config.dca_per_grid / buy_price
        cost = qty * buy_price
        if self.total_invested + cost > self.config.max_position:
            logger.warning(f"層 {level} 達到最大倉位限制，跳過 DCA 買入")
            return

        try:
            order = self.exchange.create_market_buy_order(self.config.symbol, qty)
            self.positions[level] = {
                "entry_price": buy_price,
                "qty": qty,
                "sold": False,
                "order_id": order.get("id")
            }
            self.total_invested += cost
            logger.info(f"📥 DCA 層 {level} 買入：價格={buy_price:.4f}, 數量={qty:.6f}, 成本={cost:.2f} USDT")
        except Exception as e:
            logger.error(f"❌ DCA 買入失敗（層 {level}）：{e}")

    def _place_tp_sell(self, level: int):
        """在指定網格止盈賣出"""
        if level not in self.positions or self.positions[level]["sold"]:
            return
        pos = self.positions[level]
        tp_price = pos["entry_price"] * (1 + self.config.tp_pct)

        try:
            order = self.exchange.create_market_sell_order(self.config.symbol, pos["qty"])
            profit = (tp_price - pos["entry_price"]) * pos["qty"]
            self.total_invested -= pos["qty"] * pos["entry_price"]
            pos["sold"] = True
            logger.info(f"✅ TP 層 {level} 止盈：價格={tp_price:.4f}, 利潤={profit:.2f} USDT")
        except Exception as e:
            logger.error(f"❌ TP 止盈失敗（層 {level}）：{e}")

    def check_and_trade(self, current_price: float):
        """檢查當前價格，執行 DCA / 止盈"""
        if self.base_price == 0:
            self._get_base_price()

        buy_prices, sell_prices = self._calculate_grid_prices(self.base_price)

        for i, buy_p in enumerate(buy_prices):
            level = i + 1
            # DCA 買入：價格跌破網格
            if current_price <= buy_p:
                if level not in self.positions or self.positions[level]["sold"]:
                    if self._atr_filter():
                        self._place_dca_buy(level, buy_p)

            # 止盈：價格回升到止盈位
            if level in self.positions and not self.positions[level]["sold"]:
                tp_p = self.positions[level]["entry_price"] * (1 + self.config.tp_pct)
                if current_price >= tp_p:
                    self._place_tp_sell(level)

    def run_backtest(self, df: pd.DataFrame) -> dict:
        """歷史回測"""
        base_p = self.base_price if self.base_price > 0 else df["close"].iloc[0]
        buy_prices, sell_prices = self._calculate_grid_prices(base_p)

        capital = self.config.max_position
        total_invested = 0.0
        total_profit = 0.0
        dca_entries = []
        tp_exits = []
        grid_states: Dict[int, dict] = {}

        for i in range(30, len(df)):
            price = df["close"].iloc[i]
            row_str = f"[回測 {i}] 價格={price:.4f}"
            triggered = []

            for lvl in range(1, self.grid_levels + 1):
                buy_p = buy_prices[lvl - 1]
                tp_p  = buy_p * (1 + self.config.tp_pct)

                # DCA 買入
                if price <= buy_p and (lvl not in grid_states or grid_states[lvl]["sold"]):
                    if total_invested + self.config.dca_per_grid <= capital:
                        qty = self.config.dca_per_grid / buy_p
                        grid_states[lvl] = {"entry": buy_p, "qty": qty, "sold": False}
                        total_invested += self.config.dca_per_grid
                        dca_entries.append({"level": lvl, "price": buy_p, "qty": qty})
                        triggered.append(f"層{lvl} DCA@{buy_p:.2f}")

                # 止盈
                if lvl in grid_states and not grid_states[lvl]["sold"]:
                    if price >= tp_p:
                        profit = (tp_p - grid_states[lvl]["entry"]) * grid_states[lvl]["qty"]
                        total_profit += profit
                        tp_exits.append({"level": lvl, "exit": tp_p, "profit": profit})
                        grid_states[lvl]["sold"] = True
                        triggered.append(f"層{lvl} TP@{tp_p:.2f} +{profit:.2f}")

            if triggered:
                logger.info(f"{row_str} | {', '.join(triggered)}")

        return {
            "base_price": base_p,
            "grid_levels": self.grid_levels,
            "grid_spacing_pct": self.config.grid_spacing * 100,
            "total_dca_entries": len(dca_entries),
            "total_tp_exits": len(tp_exits),
            "total_invested": total_invested,
            "total_profit": total_profit,
            "net_return": total_profit / total_invested * 100 if total_invested > 0 else 0,
            "capital_used": capital,
        }

    def live_run(self, poll_seconds: int = 300):
        """實盤運行（每 5 分鐘檢查一次）"""
        logger.info("🟢 網格 DCA 實盤模式啟動（每 5 分鐘檢查）")
        self._get_base_price()
        buy_prices, _ = self._calculate_grid_prices(self.base_price)
        logger.info(f"基準價：{self.base_price:.4f}")
        logger.info(f"買入網格：{[f'{p:.4f}' for p in buy_prices]}")

        while True:
            try:
                ticker = self.exchange.fetch_ticker(self.config.symbol)
                current = ticker["last"]
                self.check_and_trade(current)
                logger.info(f"監控中... 現價={current:.4f}, 已投入={self.total_invested:.2f}/{self.config.max_position:.2f} USDT")
            except Exception as e:
                logger.error(f"輪詢錯誤：{e}")
            time.sleep(poll_seconds)


def main():
    config = GridDCAConfig()
    strat  = GridDCA("hyperliquid", config)

    # 自動獲取基準價
    strat._get_base_price()

    # 回測
    print("=" * 50)
    print("📊 網格 DCA 回測")
    print("=" * 50)

    # 模擬數據（實際使用時替換為真實 K 線數據）
    dates = pd.date_range(start="2025-01-01", periods=200, freq="4h")
    import numpy as np
    np.random.seed(42)
    prices = strat.base_price * (1 + np.cumsum(np.random.randn(200) * 0.02))
    df = pd.DataFrame({"close": prices}, index=dates)

    result = strat.run_backtest(df)
    print(f"基準價：{result['base_price']:.4f}")
    print(f"網格層數：{result['grid_levels']} | 間距：{result['grid_spacing_pct']:.1f}%")
    print(f"DCA 買入次數：{result['total_dca_entries']}")
    print(f"止盈次數：{result['total_tp_exits']}")
    print(f"總投入：{result['total_invested']:.2f} USDT")
    print(f"總盈利：{result['total_profit']:.2f} USDT")
    print(f"收益率：{result['net_return']:.2f}%")

    # strat.live_run()


if __name__ == "__main__":
    main()
